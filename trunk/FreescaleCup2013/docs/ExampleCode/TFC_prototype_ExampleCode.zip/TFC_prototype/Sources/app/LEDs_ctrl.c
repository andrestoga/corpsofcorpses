/*============================================================================*/
/*                     AZOR - EMBEDDED SYSTEMS SOFTWARE                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:        LEDs_ctrl.c
* version:         1.0 
* created_by:      David Robles  
* date_created:    Sep 13 2013 
*=============================================================================*/
/* DESCRIPTION : C source for LEDs management                                 */
/*============================================================================*/
/* FUNCTION COMMENT : This file describes the C source template according to  */
/* the new software platform                                                  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 12/08/2013  |                               | David Robles     */
/* First version of this source                                               */
/*============================================================================*/

/* Includes */
/* -------- */
#include "LEDs_ctrl.h"
#include "..\sdl\rgbLED.h"
#include "..\mcl\ADC.h"
#include "..\mcl\IO_ports.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 
/* BYTE constants */

/* WORD constants */

/* LONG and STRUCTURE constants */

/* Custom type constants */


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTE RAM variables */
T_UBYTE rub_LEDs_ctrl_BattLevel = 0;
/* WORD RAM variables */

/* LONG and STRUCTURE RAM variables */

/* Custom type RAM variables */
typedef enum
{
	RGB_LED_STATE_OFF = 0,
	RGB_LED_STATE_RED,
	RGB_LED_STATE_GREEN,
	RGB_LED_STATE_BLUE,
	RGB_LED_STATE_RED_GREEN,
	RGB_LED_STATE_RED_BLUE,
	RGB_LED_STATE_GREEN_BLUE,
	RGB_LED_STATE_ALL	
}E_RGB_LED_STATE;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */


/* Exported functions prototypes */
/* ----------------------------- */

/* Inline functions */
/* ---------------- */
/**************************************************************
 *  Name                 : inline_func	2
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/


/* Private functions */
/* ----------------- */
/**************************************************************
 *  Name                 : private_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/


/* Exported functions */
/* ------------------ */
/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void LEDs_ctrl_rgb_led_fsm(void)
{
	PRIVATE_DATA E_RGB_LED_STATE re_rgbLED_secuence_st = RGB_LED_STATE_OFF;
	
	switch(re_rgbLED_secuence_st)
	{
		case RGB_LED_STATE_OFF:
			rgbLED_SetState(RGB_LED_OFF);
			re_rgbLED_secuence_st = RGB_LED_STATE_RED;
			break;
		case RGB_LED_STATE_RED:
			rgbLED_SetState(RGB_LED_RED);
			re_rgbLED_secuence_st = RGB_LED_STATE_GREEN;
			break;
		case RGB_LED_STATE_GREEN:
			rgbLED_SetState(RGB_LED_GREEN);
			re_rgbLED_secuence_st = RGB_LED_STATE_BLUE;
			break;
		case RGB_LED_STATE_BLUE:
			rgbLED_SetState(RGB_LED_BLUE);
			re_rgbLED_secuence_st = RGB_LED_STATE_RED_GREEN;
			break;		
		case RGB_LED_STATE_RED_GREEN:
			rgbLED_SetState(RGB_LED_RED_GREEN);
			re_rgbLED_secuence_st = RGB_LED_STATE_RED_BLUE;
			break;
		case RGB_LED_STATE_RED_BLUE:
			rgbLED_SetState(RGB_LED_RED_BLUE);
			re_rgbLED_secuence_st = RGB_LED_STATE_GREEN_BLUE;
			break;
		case RGB_LED_STATE_GREEN_BLUE:
			rgbLED_SetState(RGB_LED_GREEN_BLUE);
			re_rgbLED_secuence_st = RGB_LED_STATE_ALL;
			break;
		case RGB_LED_STATE_ALL:
			rgbLED_SetState(RGB_LED_ALL);
			re_rgbLED_secuence_st = RGB_LED_STATE_RED;
			break;
		default:
			re_rgbLED_secuence_st = RGB_LED_STATE_OFF;
			break;
	}
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void LEDs_ctrl_rgb_led_init(void)
{
	rgbLED_initialize();
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
#define BATT_LEDS_VLTG_LVL4 11
#define BATT_LEDS_VLTG_LVL3 10
#define BATT_LEDS_VLTG_LVL2 9
#define BATT_LEDS_VLTG_LVL1 8
void LEDs_ctrl_BattLevel_LEDs (void)
{
	T_UBYTE lub_VoltageLevel = 0;
	/* Read voltage from ADC */
	rub_LEDs_ctrl_BattLevel = BatSenseADC_Value;
	/* Determine level according thresholds */
	if(BatSenseADC_Value >= 99) // Full voltage level (from 6.7 to above)
	{
		lub_VoltageLevel = 4;
	}
	else if((BatSenseADC_Value < 99) && (BatSenseADC_Value >= 92)) // Voltage level 3 (from 6.2 to 6.7)
	{
		lub_VoltageLevel = 3;
	}
	else if((BatSenseADC_Value < 92) && (BatSenseADC_Value >= 85)) // Voltage level 2 (from 5.7 to 6.2)
	{
		lub_VoltageLevel = 2;
	}
	else if((BatSenseADC_Value < 85) && (BatSenseADC_Value >= 77)) // Voltage level 1 (from 5.2 to 5.7)
	{
		lub_VoltageLevel = 1;
	}
	else // Low voltage level (5.2 and below)
	{
		lub_VoltageLevel = 0;
	}
	/* Set LEDs state according level */
	switch(lub_VoltageLevel)
	{
		case 4:
			/* Turn On all the batt LEDs */
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
		case 3:
			/* Turn On LEDs from LVL1 to LVL 3 only */
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
		case 2:
			/* Turn On LEDs from LVL1 to LVL 2 only */
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
		case 1:
			/* Turn On LED LVL1 only */
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Set_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
		case 0:
			/* Togle LED LVL1 only */
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Toggle_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
		default:
			/* Togle LED LVL4 only */
			IO_ports_Toggle_PortB_pin(BATT_LEDS_VLTG_LVL4);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL3);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL2);
			IO_ports_Clear_PortB_pin(BATT_LEDS_VLTG_LVL1);
		break;
	
	}
}
