#ifndef ARM_SYSTICK_H_
#define ARM_SYSTICK_H_

void InitSysTick();

#define SYSTICK_FREQUENCY 1000


#endif /* SYSTICK_H_ */

