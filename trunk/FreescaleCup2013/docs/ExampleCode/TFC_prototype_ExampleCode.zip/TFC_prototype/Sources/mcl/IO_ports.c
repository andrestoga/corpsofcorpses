/*============================================================================*/
/*                     AZOR - EMBEDDED SYSTEMS SOFTWARE                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:        IO_ports.c
* version:         1.0 
* created_by:      David Robles  
* date_created:    sep 13 2013 
*=============================================================================*/
/* DESCRIPTION : C source for io ports management                             */
/*============================================================================*/
/* FUNCTION COMMENT : This file describes the C source template according to  */
/* the new software platform                                                  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 13/09/2013  |                               | David Robles     */
/* First version of this source                                               */
/*============================================================================*/

/* Includes */
/* -------- */
#include "IO_ports.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 
/* BYTE constants */

/* WORD constants */

/* LONG and STRUCTURE constants */

/* Custom type constants */


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTE RAM variables */

/* WORD RAM variables */

/* LONG and STRUCTURE RAM variables */

/* Custom type RAM variables */

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */


/* Exported functions prototypes */
/* ----------------------------- */

/* Inline functions */
/* ---------------- */
/**************************************************************
 *  Name                 : inline_func	2
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/


/* Private functions */
/* ----------------- */
/**************************************************************
 *  Name                 : private_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/


/* Exported functions */
/* ------------------ */
/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_initialize_stage_0 (void)
{
	//enable Clocks to all ports
		
	SIM_SCGC5 |= SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK | SIM_SCGC5_PORTE_MASK;
	
	//Setup Pins as GPIO
	PORTE_PCR21 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;   // H-Bridge Enable => TFC_HBRIDGE_EN_LOC
	PORTE_PCR20 = PORT_PCR_MUX(1);    // H-Bridge Fault
	
	//Port for Pushbuttons
	PORTC_PCR13 = PORT_PCR_MUX(1);   // SW1
	PORTC_PCR17 = PORT_PCR_MUX(1);   // SW2
	
	
	//Ports for DIP Switches (SW3)
	PORTE_PCR2 = PORT_PCR_MUX(1); // 1
	PORTE_PCR3 = PORT_PCR_MUX(1); // 2
	PORTE_PCR4 = PORT_PCR_MUX(1); // 3
	PORTE_PCR5 = PORT_PCR_MUX(1); // 4
	
	//Ports for LEDs
	PORTB_PCR8 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;   // D3 (most inside target) 
	PORTB_PCR9 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;   // D4
	PORTB_PCR10 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;  // D5 
	PORTB_PCR11 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;  // D6 (most outside target)  
	
	
	//Setup the output pins
	GPIOE_PDDR =  TFC_HBRIDGE_EN_LOC;  
	GPIOB_PDDR =  TFC_BAT_LED0_LOC	| TFC_BAT_LED1_LOC | TFC_BAT_LED2_LOC | TFC_BAT_LED3_LOC;
	
	// Set the H bringe as disable
	TFC_HBRIDGE_DISABLE;	
	
	// RGB LED
	/* Set the PTB18 pin multiplexer to GPIO mode */
	PORTB_PCR18 = PORT_PCR_MUX(1); // Red LED
	/* Set the PTB19 pin multiplexer to GPIO mode */
	PORTB_PCR19 = PORT_PCR_MUX(1); // Green LED
	/* Set the PTD1 pin multiplexer to GPIO mode */
	PORTD_PCR1 = PORT_PCR_MUX(1); // Blue LED

	/* Set the initial output state to high */
	GPIOB_PSOR |= BIT_POSITION(18);

	/* Set the pins direction to output */
	GPIOB_PDDR |= BIT_POSITION(18);;

	/* Set the initial output state to high */
	GPIOB_PSOR |= BIT_POSITION(19);
	/* Set the pins direction to output */
	GPIOB_PDDR |= BIT_POSITION(19);

	/* Set the initial output state to high */
	GPIOD_PSOR |= BIT_POSITION(1);
	/* Set the pins direction to output */
	GPIOD_PDDR |= BIT_POSITION(1);
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_Set_PortB_pin(T_UBYTE lub_pin_number)
{
	if(lub_pin_number < 32)
	{
		GPIOB_PSOR = BIT_POSITION(lub_pin_number);
	}
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_Clear_PortB_pin(T_UBYTE lub_pin_number)
{
	if(lub_pin_number < 32)
	{
		GPIOB_PCOR = BIT_POSITION(lub_pin_number);
	}
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_Toggle_PortB_pin(T_UBYTE lub_pin_number)
{
	if(lub_pin_number < 32)
	{
		GPIOB_PTOR = BIT_POSITION(lub_pin_number);
	}
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_Set_PortD_pin(T_UBYTE lub_pin_number)
{
	if(lub_pin_number < 32)
	{
		GPIOD_PSOR = BIT_POSITION(lub_pin_number);
	}
}

/**************************************************************
 *  Name                 :	export_func
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    [yes / No]
 **************************************************************/
void IO_ports_Clear_PortD_pin(T_UBYTE lub_pin_number)
{
	if(lub_pin_number < 32)
	{
		GPIOD_PCOR = BIT_POSITION(lub_pin_number);
	}
}

