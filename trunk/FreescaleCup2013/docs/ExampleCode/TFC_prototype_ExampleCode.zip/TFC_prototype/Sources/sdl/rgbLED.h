/****************************************************************************
 * Project developed as a simple Blink the LED's to 
 * demonstrate basic CodeWarrior functionality and capability.
 * Borrowed from Freedom Example Projects: Blinky
 * 
 * Date: 13 Sept 2013
 * Author: David Robles
 * Revision Level 1.0
 */
#ifndef RGBLED_H                       /* To avoid double inclusion */
#define RGBLED_H

#include "stdtypedef.h"
#include "derivative.h" /* include peripheral declarations */

/* Mapping of RGB LED conections */
#define RGBLED_PIN_RED (18)
#define RGBLED_PIN_GREEN (19)
#define RGBLED_PIN_BLUE (1)

typedef enum
{
	RGB_LED_OFF = 0,
	RGB_LED_RED,
	RGB_LED_GREEN,
	RGB_LED_BLUE,
	RGB_LED_RED_GREEN,
	RGB_LED_RED_BLUE,
	RGB_LED_GREEN_BLUE,
	RGB_LED_ALL	
}E_RGB_LED_COLORS;

void rgbLED_initialize(void);
void rgbLED_RedOn(void);
void rgbLED_RedOff(void);
void rgbLED_GreenOn(void);
void rgbLED_GreenOff(void);
void rgbLED_BlueOn(void);
void rgbLED_BlueOff(void);
void rgbLED_SetState(E_RGB_LED_COLORS re_rgb_LED_color);



#endif /* RGB_LEDS_H */
