/****************************************************************************
 * Date: 13 Sept 2013
 * Author: David Robles
 * Revision Level 1.0
 */

#include "stdtypedef.h"
#include "derivative.h" /* include peripheral declarations */
#include "..\mcl\IO_ports.h"
#include "rgbLED.h"

void rgbLED_SetState(E_RGB_LED_COLORS re_rgb_LED_color)
{
	switch(re_rgb_LED_color)
	{
		case RGB_LED_OFF: /* All off */
			rgbLED_RedOff();
			rgbLED_GreenOff();
			rgbLED_BlueOff();
			break;
		case RGB_LED_RED: /* red on */
			rgbLED_RedOn();
			rgbLED_GreenOff();
			rgbLED_BlueOff();
			break;
		case RGB_LED_GREEN: /* green on */
			rgbLED_RedOff();
			rgbLED_GreenOn();
			rgbLED_BlueOff();
			break;
		case RGB_LED_BLUE: /* blue on */
			rgbLED_RedOff();
			rgbLED_GreenOff();
			rgbLED_BlueOn();
			break;
		case RGB_LED_RED_GREEN: /* red + green */
			rgbLED_RedOn();
			rgbLED_GreenOn();
			rgbLED_BlueOff();
			break;
		case RGB_LED_RED_BLUE: /* red + blue */
			rgbLED_RedOn();
			rgbLED_GreenOff();
			rgbLED_BlueOn();
			break;
		case RGB_LED_GREEN_BLUE: /* green + blue */
			rgbLED_RedOff();
			rgbLED_GreenOn();
			rgbLED_BlueOn();
			break;
		case RGB_LED_ALL: /* All on */
			rgbLED_RedOn();
			rgbLED_GreenOn();
			rgbLED_BlueOn();
			break;
		default: /* All off */
			rgbLED_RedOff();
			rgbLED_GreenOff();
			rgbLED_BlueOff();
			break;
	}
}

void rgbLED_RedOn()
{
	IO_ports_Clear_PortB_pin(RGBLED_PIN_RED);
}

void rgbLED_RedOff()
{
	IO_ports_Set_PortB_pin(RGBLED_PIN_RED);
}

void rgbLED_GreenOn()
{
	IO_ports_Clear_PortB_pin(RGBLED_PIN_GREEN);
}

void rgbLED_GreenOff()
{
	IO_ports_Set_PortB_pin(RGBLED_PIN_GREEN);
}

void rgbLED_BlueOn()
{
	IO_ports_Clear_PortD_pin(RGBLED_PIN_BLUE);
}

void rgbLED_BlueOff()
{
	IO_ports_Set_PortD_pin(RGBLED_PIN_BLUE);
}


/********************************************************************/
/*	rgbLED_initialize()
 * initialize the ports for LEDs
 * ******************************************************************/
 

void rgbLED_initialize(void)
{
	
}

 
