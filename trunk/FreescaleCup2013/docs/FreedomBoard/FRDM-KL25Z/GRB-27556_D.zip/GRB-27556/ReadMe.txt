README for GRB-27556_D.zip

Company Part Number: 170-27556 REV D

Date : Mon, 16 Jul 2012 22:31:13 GMT

Freescale Semiconductor
Periferico Sur #8110
Col. El Mante
Tlaquepaque, Jalisco, Mexico
C.P. 45609

Company Contact: Ricardo Cazarez
Work Phone: (52)33-32832100 Ext. 2090
Email:	 Cazarez.Ricardo@freescale.com