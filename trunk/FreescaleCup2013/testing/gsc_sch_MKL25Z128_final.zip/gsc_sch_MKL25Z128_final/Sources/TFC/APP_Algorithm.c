#include "TFC\TFC.h"

#define LINE_CENTER	63
#define SERP_OFFSET	25

#define DEAD_ZONE	3

#define CURVE		30
#define CURVE_LOW	50

#define KD			1.5f
#define KP_H		1.6f
#define KP_L		.9f
#define TIME		5.0f

uint8_t StateCurve = 0;
uint8_t Benchmark = 0;

uint8_t GoalCounter = 0;
uint8_t StateGoal = 1;

uint8_t GoalDetected = 0;
uint8_t GoalNotDetected = 0;

float NewPwm = 0.0f;

/* Private functions prototypes */
/* ---------------------------- */
float getDifferential(float error);
void goalDetector(void);
uint8_t getLineCenterAverage(void);
uint8_t getLineCenterAverage2(void);
float convertRange(float originalStart, float originalEnd, // original range
    float newStart, float newEnd, // desired range
    float value); // value to convert)

/* Exported functions prototypes */
/* ----------------------------- */
void vfnSecondVersion(void);

/* Private functions */
/* ----------------- */

void goalDetector(void)
{
	if(IsGoalDetected == 1 || IsGoalDetected2 == 1)
	{
		GoalDetected = 1;
	}
	
	if(StateGoal == 1)
	{		
		if ( GoalDetected )
		{
			if ( IsGoalDetected != 1 && GoalNotDetected > 300 )
			{
				StateGoal = 2;
				GoalDetected = 0;
				GoalNotDetected = 0;
				TFC_BAT_LED1_ON;
			}
			else
			{
				GoalNotDetected++;
			}
		}
	}
	else if(StateGoal == 2)
	{
		if( GoalDetected )
		{
			TFC_HBRIDGE_DISABLE;
			
			if ( IsGoalDetected != 1 && GoalNotDetected > 300 )
			{
				GoalDetected = 0;
				GoalNotDetected = 0;	
				TFC_BAT_LED1_OFF;
				StateGoal = 1;
			}
			else
			{
				GoalNotDetected++;
			}
		}
	}
}

float getDifferential(float error)
{
	return error * ( KD / TIME );
}

uint8_t getLineCenterAverage(void)
{	
	uint8_t i;
	
	uint16_t tmp = 0;
	
	if (CameraAvg == 1) {
		return ub_Black_Strip_Center; 
	}
	else
	{
		for (i = 0; i < CameraAvg; i++)
		{
			tmp += ub_Line_Average[i];
		}
			
		tmp /= CameraAvg;
		
		return tmp;
	}
}

uint8_t getLineCenterAverage2(void)
{	
	uint8_t i;
	
	uint16_t tmp = 0;
	
	if (CameraAvg == 1) {
		return ub_Black_Strip_Center2; 
	}
	else
	{
		for (i = 0; i < CameraAvg; i++)
		{
			tmp += ub_Line_Average2[i];
		}
			
		tmp /= CameraAvg;
		
		return tmp;
	}
}

float convertRange(float originalStart, float originalEnd, // original range
    float newStart, float newEnd, // desired range
    float value) // value to convert)
{
	float scale = (float)(newEnd - newStart) / (originalEnd - originalStart);
    return (float)(newStart + ((value - originalStart) * scale));
}


/* Exported functions */
/* ------------------ */

void vfnSecondVersion(void)
{	
	int8_t difference = 0;
	float result = 0.0f;
	int16_t value = 0;
	int16_t value2 = 0;
	float error = 0.0f;
	int8_t middlePoint = 0;
	
	float rightWheeSpeed = 0.0;
	float leftWheeSpeed = 0.0;
	
	//Set a constant speed
//	NewPwm = ( MAL_ReadPot(0) + 1 ) / 2;
//	NewPwm = 0.507204f;
	NewPwm = 0.490842f;
	
	value = getLineCenterAverage();
	value2 = getLineCenterAverage2();
	
//	goalDetector();
	
	//Floating dead zone
	if( getAbs(Benchmark - value2) >= DEAD_ZONE )
	{
		Benchmark = value;
		
		difference = (LINE_CENTER - value2) * -1;
		middlePoint = difference / 2;
		
		error = convertRange(0.0f, 127.0f, -1.0f, 1.0f, LINE_CENTER + middlePoint);
		
		//Turning left
		//Left wheel slower than right wheel
		if(value2 < (LINE_CENTER - SERP_OFFSET))
		{	
			result = error * KP_H + getDifferential(error);
			
			rightWheeSpeed = NewPwm - ( ( NewPwm * CURVE ) / 100 );
			
			if (rightWheeSpeed < 0.0) {
				rightWheeSpeed = 0.0;
			}
			
			leftWheeSpeed = NewPwm - ( ( NewPwm * CURVE_LOW ) / 100 );
			
			if (leftWheeSpeed < 0.0) {
				leftWheeSpeed = 0.0;
			}
			
//			HAL_SetMotorPWM(rightWheeSpeed, leftWheeSpeed);		//Without SPEED CONTROL
					HAL_SetSpeed(rightWheeSpeed, leftWheeSpeed);
			
			//Blue
			RED_OFF;
			BLUE_ON;
			GREEN_OFF;
			
		}//Turning right, Right wheel slower than left wheel
		else if(value2 > (LINE_CENTER + SERP_OFFSET))
		{
			result = error * KP_H + getDifferential(error);
			
			leftWheeSpeed = NewPwm - ( ( NewPwm * CURVE ) / 100 );
			
			if (leftWheeSpeed < 0.0) {
				leftWheeSpeed = 0.0;
			}
			
			rightWheeSpeed = NewPwm - ( ( NewPwm * CURVE_LOW ) / 100 );
			
			if (rightWheeSpeed < 0.0) {
				rightWheeSpeed = 0.0;
			}
			
//			HAL_SetMotorPWM(rightWheeSpeed, leftWheeSpeed);		//Without SPEED CONTROL
					HAL_SetSpeed(rightWheeSpeed, leftWheeSpeed);
			
			//Purple
			RED_ON;
			BLUE_ON;
			GREEN_OFF;
		}
		else
		{
			result = error * KP_L + getDifferential(error);
			
//			HAL_SetMotorPWM(NewPwm, NewPwm);		//Without SPEED CONTROL
					HAL_SetSpeed(NewPwm, NewPwm);
			
			//Green
			RED_OFF;
			BLUE_OFF;
			GREEN_ON;
		}
		
			if (result > 1.0) {
				result = 1.0;
			}
		
			if (result < -1.0) {
				result = -1.0;
			}
		
		HAL_SetServo(result);
	}
}
