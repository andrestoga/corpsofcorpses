/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Include:        %APP_Linear_Camera.h%
* Instance:         RPL_1
* %version:         1.3 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : Header file for the application layer of the linear camera   */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the declarations of the the variables*/
/*					  and functions of the application layer of the linear	  */
/*					  camera.								                  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  | SAR/SIF/SCN_xxx               | Andres Torres    */
/*  1.1      | 04/10/2012  |                               | Andres Torres    */
/*  1.2      | 07/10/2012  |                               | Andres Torres    */
/*  1.3      | 13/11/2012  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

#ifndef APP_LINEAR_CAMERA_H                               /* To avoid double inclusion */
#define APP_LINEAR_CAMERA_H

/* Includes */
/* -------- */

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported types and constants */
/* ---------------------------- */

/* Types definition */
/* typedef */
#include "TFC\TFC.h"
#include "TFC\HAL_Linear_Camera.h"

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Functions prototypes */

extern void vfn_calibrateLine(void);
extern void vfn_saveLineCenterPosition(void);
extern void vfn_saveLineCenterPosition2(void);
extern void vfn_ProcessPixels_V2();
extern uint16_t getAbs(int16_t num);

/* Functions macros */

/* Exported defines */

/*!
  \def CAMERA_AVG
  Number of line centers to store.
*/
#define CAMERA_AVG	4

/*==================================================*/ 
/* Declaration of exported constants                */
/*==================================================*/ 
/* BYTE constants */

extern uint8_t ub_Black_Strip_Width;
extern uint8_t ub_Black_Strip_Center;
extern uint8_t ub_IsGoal;
extern uint8_t ub_Can_Process_Pixels;

extern uint8_t IsGoalDetected;
extern uint8_t IsGoalDetected2;

extern uint8_t ub_Black_Strip_Width2;
extern uint8_t ub_Black_Strip_Center2;
extern uint8_t ub_IsGoal2;

extern uint8_t ub_Line_Average[20];
extern uint8_t ub_Line_Average2[20];

extern int8_t sb_BLACK_STRIP_WIDTH_MEASU;
extern const int8_t sb_RANGE;

extern uint16_t MaxSlopeMag;

extern volatile uint8_t FailCamLectCounter;

/* WORD constants */

extern int16_t sw_Threshold;

extern uint8_t CameraAvg;

extern uint8_t GoalDetector;
extern uint8_t GoalDetector2;

extern volatile uint8_t FailCamLectCounter;
extern volatile uint8_t FailCamLectCounter2;

extern volatile uint8_t SuccCamLecturesCounter;
extern volatile uint8_t SuccCamLecturesCounter2;

/* LONG and STRUCTURE constants */
 
/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTES */

extern uint8_t width;
extern uint8_t center;

extern uint8_t width2;
extern uint8_t center2;

/* WORDS */

/* LONGS and STRUCTURES */

#endif
