/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.h
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:05:01 2013 %
*=============================================================================*/
/* DESCRIPTION :          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

#ifndef APP_ALGOORA_H_
#define APP_ALGOORA_H_

/* Register definitions for selected microcontroller */
#include "TFC\TFC.h"

void vfnAlgorithmsORA(void);

/*Steering*/
void vfnDiff_1(int8_t diff, int8_t coeff);

/*Speed*/
void vfnSpeedDiff(int8_t diff, float speed_ref, float coeff_turn);

/*Camera used*/
void Collision(void);

/*Other*/
float convertRangeValue(float originalStart, float originalEnd, // original range
float newStart, float newEnd, // desired range
float value); // value to convert)
void vfnMachineStateGoal(void);
void TimerGoal(void);
void ResetGoal(void);

/* Machine State */
void vfnMachineState(int8_t diff, int8_t diff2);
void vfnLedState(void);
//void vfnAlgorithmState(int8_t diff, int8_t diff2, float speed_low, float speed_high);
void vfnAlgorithmState(int8_t diff, int8_t diff2);

#endif /* APP_ALGOORA_H_ */
