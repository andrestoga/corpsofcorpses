/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Include:        %APP_Machine_State.h%
* Instance:         RPL_1
* %version:         1.0 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : Header file for the machine state file                       */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the variables and functions declara  */
/*					  tions of the machine state file.			              */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  | SAR/SIF/SCN_xxx               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

#ifndef APP_MACHINE_STATE_H                               /* To avoid double inclusion */
#define APP_MACHINE_STATE_H

/* Includes */
/* -------- */

/* Exported types and constants */
/* ---------------------------- */

/* Types definition */
/* typedef */

/*==================================================*/ 
/* Declaration of exported constants                */
/*==================================================*/ 
/* BYTE constants */

/* WORD constants */

/* LONG and STRUCTURE constants */


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTES */

/* WORDS */

/* LONGS and STRUCTURES */

/**
 *
 * \enum    STATE
 *
 * \brief   States of the machine state. 
**/
enum STATE
{
      FIRST_STATE, SECOND_STATE, THIRD_STATE, FOUR_STATE, NUM_STATES
};


extern void (*ptrFctnMachineState[NUM_STATES]) (void);


extern enum STATE en_State;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Functions prototypes */

extern void vfnInitStates(void);

/* Functions macros */

/* Exported defines */

#endif
