/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.h
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:05:01 2013 %
*=============================================================================*/
/* DESCRIPTION :          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

#ifndef APP_ALGOORA_H_
#define APP_ALGOORA_H_

/* Register definitions for selected microcontroller */
#include "TFC\TFC.h"

void vfnAlgorithmsORA(void);

/*Steering*/
void vfnDiff_1(int8_t diff);
void vfnDiff_2(int8_t diff);
void vfnDiff_3(int8_t diff);

/*Speed*/
void vfnConstant(float speed_const);
void vfnConstant2(float speed_right, float speed_left);
void vfnTwoSpeeds(int8_t diff, float low_speed, float high_speed);
void vfnSpeedsHard(int8_t diff, float low_speed, float high_speed);
void vfnSpeedsSoft(int8_t diff, float low_speed, float high_speed);

#endif /* APP_ALGOORA_H_ */
