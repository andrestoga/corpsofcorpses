/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for algorithms by Oscar									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the algorithms			  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"

#define CENTER_LINE		63

void vfnAlgorithmsORA(void){
	float pot_0, pot_1;
	int8_t ub_center_temp;
	int8_t difference;
	uint32_t i = 0;
	
	//Read pots
	pot_0 = (MAL_ReadPot(0)+1)/2;
	pot_1 = (MAL_ReadPot(1)+1)/2;
	
	//Line position
	ub_center_temp = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127
	
	difference = ub_center_temp - CENTER_LINE;			//Values from -63 to 64
	
	//Select algorithm
	switch(TFC_GetDIP_Switch()&0x03){
		case 0:
			vfnDiff_1(difference);
			vfnTwoSpeeds(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
			break;
		case 1:
			vfnDiff_2(difference);
			vfnTwoSpeeds(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
			break;
		case 2:
			vfnDiff_3(difference);
			vfnTwoSpeeds(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
			break;
		case 3:
			//vfnPid(difference,pot_1);
//			vfnConstant(pot_0);
			break;
	}
	
	//It sends information using serial port
	switch((TFC_GetDIP_Switch()>>2)&0x03){
		case 0:
			//Nothing
			break;
		case 1:
			//After binarization
			TERMINAL_PRINTF("%d ", pat_info.value);
			TERMINAL_PRINTF("%d ", pat_info.valid);
			TERMINAL_PRINTF("%d ", ub_Black_Strip_Center);
			TERMINAL_PRINTF("%d ", ub_Black_Strip_Width);
			TERMINAL_PRINTF("\r\n");
		 
			for(i = 0;i < 128;i++)
			{
				TERMINAL_PRINTF("%d",ub_Bin_Pixels[i]);
//				TERMINAL_PRINTF("%d",LineScanImage0[i]);
			} 
			TERMINAL_PRINTF("\r\n");
			break;
		case 2:
			//Labview application
			TERMINAL_PRINTF("\r\n");
			TERMINAL_PRINTF("L:");
				
			for(i=0;i<128;i++)
			{
				TERMINAL_PRINTF("%X,",LineScanImage0[i]);
			}
			
			for(i=0;i<128;i++)
			{
				TERMINAL_PRINTF("%X",LineScanImage1[i]);
				 
				if(i==127)
					TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
				else
					TERMINAL_PRINTF(",",LineScanImage1[i]);
			}
			break;
		case 3:
			//Speed sensor
			TERMINAL_PRINTF("%d", (uint8_t)(HAL_GetSpeed()*100));
			TERMINAL_PRINTF("\r\n");
			break;
	}
}
	
/*Steering*/
void vfnDiff_1(int8_t diff){
	float servo_position;
	int8_t coeff = 50;
	
	servo_position = (float)((float)diff/(float)coeff);
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_2(int8_t diff){
	float servo_position;
	int8_t coeff = 35;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position;
	
	if(diff < 0){
		servo_position = servo_position * (-1);
	}
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_3(int8_t diff){
	float servo_position;
	int8_t coeff = 40;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position*servo_position;
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}


/*Speed*/
void vfnConstant(float speed_const){
	HAL_SetSpeed(speed_const);				//With SPEED CONTROL
}

void vfnTwoSpeeds(int8_t diff, float low_speed, float high_speed){
	float speed_wheel;
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 10;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel = high_speed;
	}else{
		speed_wheel = low_speed;
	}
	
	HAL_SetSpeed(speed_wheel);				//With SPEED CONTROL
}
