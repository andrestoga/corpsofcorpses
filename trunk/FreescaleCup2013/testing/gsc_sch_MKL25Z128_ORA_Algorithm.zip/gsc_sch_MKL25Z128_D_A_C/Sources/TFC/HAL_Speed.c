/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            HAL_MOTORS.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Tuesday October 15 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for DC Motors 									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the DC motors				  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 15/10/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"



/**********************************************************************************************/

#define FTM2_CLOCK				(CORE_CLOCK/2)
#define FTM2_CLK_PRESCALE       5// Prescale Selector value - see comments in Status Control (SC) section for more details
								//Divided by 32

#define COUNT_VAL				10			
#define COUNTS_MAX				18750		//Counts for a frequency of 40Hz
#define COUNTS_MIN				750			//Counts for a frequency of 1kHz

//HAL_SetSpeed()
float RefSpeed;
//HAL_ControlSpeed()
float power_motor = 0;
float error = 0;
float lastError = 0;
float integral = 0;
//HAL_ProcessSpeed()
volatile uint16_t SpeedBuffer[COUNT_VAL];
volatile uint8_t index = 0;

/**********************************************************************************************/
void HAL_SetSpeed(float speed_in){
	RefSpeed = speed_in;
}

float HAL_GetSpeed(void){			//from 0 to 1
	uint32_t average_count = 0;
	float current_speed;
	uint8_t temp = 0;
	
	//Get an average of counter
	do{
		average_count += SpeedBuffer[temp];	
		temp++;
	}while(temp<COUNT_VAL);
	average_count = average_count/COUNT_VAL;
	
	//Normalize speed
	if(COUNTS_MAX <= average_count){
		current_speed = 0.0;
	}else if(COUNTS_MIN > average_count){
		current_speed = 1.0;
	}else{
		current_speed = (float)((float)COUNTS_MIN/(float)average_count);
	}
	return current_speed;
}

void HAL_ControlSpeed(void){
//	HAL_SimpleControl();
	HAL_PID();
}

void HAL_SimpleControl(void){
//	float coeff = 0.1;	//0.5 //0.1 //0.05 //0.01		//Please see test charts in excel document
//	
//	error = RefSpeed - HAL_GetSpeed();
//	power_motor += (error*coeff);
//	
//	if(power_motor < 0){
//		power_motor = 0;
//	}else if(power_motor > 1.0){
//		power_motor = 1.0;
//	}
//	HAL_SetMotorPWM(power_motor,power_motor);
}

void HAL_PID(void){
	float kp = 0.05;
	float ki = 0.00001;
	float kd = 0.9;
	float current_speed;
	float derivative;
	
	current_speed = HAL_GetSpeed();		//Get the current speed
	error = RefSpeed - current_speed;	//Calculate the error
	
	integral = integral + error;		//Calculate the integral
	
	derivative = error - lastError;		//Calculate the derivative
	
	power_motor += (kp*error) + (ki*integral) + (kd*derivative);			//PID controller
//	power_motor += (kp*error) + (ki*integral);			//PI controller
//	power_motor += (kp*error) + (kd*derivative);			//PD controller
//	power_motor += (kp*error);			//P controller
	
	//Limit the power_motor
	if(power_motor < 0){
		power_motor = 0;
	}else if(power_motor > 1.0){
		power_motor = 1.0;
	}
	HAL_SetMotorPWM(power_motor,power_motor);
	
	//Save the current error for the next iteration
	lastError = error;
}

void HAL_ResetPID_Values(void){
	lastError = 0;
	integral = 0;
}

void HAL_ProcessSpeed(uint16_t counts){
	SpeedBuffer[index] = counts;
	index++;
	if(index >= COUNT_VAL){
		index = 0;
	}
}

/******************************************* Function to control Interrupt ************************************/

void FTM2_IRQHandler()
{
	uint16_t CurrValueCh_0;
	
	//Clear the overflow mask if set.   According to the reference manual, we clear by writing a logic one!
	if(TPM2_SC & TPM_SC_TOF_MASK){
	   TPM2_SC |= TPM_SC_TOF_MASK;		//Clear the flag
	   CurrValueCh_0 = COUNTS_MAX;
	}
	
	//Channel 0
	if(TPM2_C0SC & TPM_CnSC_CHF_MASK){
	   TPM2_C0SC |= TPM_CnSC_CHF_MASK;	//Clear the flag
	   
	   //Get the current counter value
	   CurrValueCh_0 = TPM2_C0V;
	}
	
	if(CurrValueCh_0 > COUNTS_MIN){
		HAL_ProcessSpeed(CurrValueCh_0);
	}
	//Reset the counter
	TPM2_CNT = 0;
}

void HAL_InitSpeedSensor()
{
               
   //Clock Setup for the TPM requires a couple steps.
   
   //1st,  set the clock mux
   //See Page 124 of f the KL25 Sub-Family Reference Manual, Rev. 3, September 2012
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK;// We Want MCGPLLCLK/2 (See Page 196 of the KL25 Sub-Family Reference Manual, Rev. 3, September 2012)
   SIM_SOPT2 &= ~(SIM_SOPT2_TPMSRC_MASK);
   SIM_SOPT2 |= SIM_SOPT2_TPMSRC(1); //We want the MCGPLLCLK/2 (See Page 196 of the KL25 Sub-Family Reference Manual, Rev. 3, September 2012)


	//Enable the Clock to the FTM2 Module
	//See Page 207 of f the KL25 Sub-Family Reference Manual, Rev. 3, September 2012
	SIM_SCGC6 |= SIM_SCGC6_TPM2_MASK; 
   
   //The TPM Module has Clock.  Now set up the peripheral
   
   //Blow away the control registers to ensure that the counter is not running
   TPM2_SC = 0;
   TPM2_CONF = 0;
   
   //While the counter is disabled we can setup the prescaler
   
   TPM2_SC = TPM_SC_PS(FTM2_CLK_PRESCALE);
   TPM2_SC |= TPM_SC_TOIE_MASK; //Enable Interrupts for the Timer Overflow
   
   //Setup Channel 0		Rising edge only
   TPM2_C0SC =  TPM_CnSC_ELSA_MASK | TPM_CnSC_CHIE_MASK;
   
   //Enable the Counter
   
   //Set the Default speed to 0
   HAL_SetSpeed(0.0);
   
   //Enable the TPM COunter
   TPM2_SC |= TPM_SC_CMOD(1);
   
   //Enable TPM1 IRQ on the NVIC
   enable_irq (INT_TPM2-16);
  
   //Enable the FTM functions on the the port
   PORTA_PCR1 = PORT_PCR_MUX(3);                        
}

