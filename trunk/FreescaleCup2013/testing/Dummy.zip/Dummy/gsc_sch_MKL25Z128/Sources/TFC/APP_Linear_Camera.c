/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:         %APP_Linear_Camera.c%
* Instance:         RPL_1
* %version:         1.2 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : C source file for the application layer of the Linear Camera */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the declarations and definitions of  */
/*					  the variables, and functions of the application layer of*/													  
/*					  the camera.											  */ 
/*					  	  											  		  */
/* 					                      									  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  |                               | Andres Torres    */
/*  1.1      | 04/10/2012  |                               | Andres Torres    */
/*  1.2      | 07/10/2012  |                               | Andres Torres    */
/*  1.3      | 13/11/2012  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*!
  \def GOAL
  Pattern for a goal.
*/
#define GOAL				42		//0010-1010 - 7 shifts
/*!
  \def GOAL_2
  Pattern for a goal.
*/
#define GOAL_2				21		//0001-0101 - 5 shifts
/*!
  \def BLACK_LINE
  Pattern for a black line.
*/
#define BLACK_LINE	 		2		//0000-0010 - 3 shifts
/*!
  \def PIN_DEBUG
  PIN for debug.
*/
#define PIN_DEBUG			1
/*!
  \def CHAR_BIT
  Useful for the function getAbs
*/
#define CHAR_BIT 			8

/* LONG and STRUCTURE constants */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 

/** \brief Tolerance range for the width of the line */
const int8_t sb_RANGE = 6;

/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/

/** \brief Left corner of the black line */
uint8_t ub_Left_Corner = 0;

/** \brief Right corner of the black line */
uint8_t ub_Right_Corner = 0;

/** \brief Width of the black line */
uint8_t ub_Black_Strip_Width = 0;
/** \brief The center of the black line */
uint8_t ub_Black_Strip_Center = 0;

/** \brief Flat that determines if we found a goal. */
uint8_t ub_IsGoal = 0;

/** \brief Flag that determines the time to proccess the pixels of the linear camera. */
uint8_t ub_Can_Process_Pixels = 0;

/** \brief Pixels of the camera binarize */
uint8_t ub_Bin_Pixels[NUM_PIXELS];

/** \brief Array of line centers. */
uint8_t ub_Line_Average[NUM_PIXELS];

extern volatile uint16_t  *LineScanImage0;

/** \brief The threshold that helps us to binarize the pixels. */
int16_t sw_Threshold = 1500;

/** \brief Holds important information about the pattern. */
Pattern_info pat_info;

/** \brief Calibrate value of the width of the line. */
int8_t sb_BLACK_STRIP_WIDTH_MEASU = 0;

/** \brief Max pixel value */
static int16_t sw_max = 0;

/** \brief Min pix value */
static int16_t sw_min = 1023;

uint8_t width = 0;
uint8_t center = 0;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */
void vfn_saveLineCenterPosition(void);
void vfn_binarize(void);
void vfn_detectLine(void);
void vfn_processPixels(void);
void vfn_calibrateThreshold(void);
void vfn_calibrateLine(void);
void vfn_isValidLine(uint8_t width, uint8_t center, uint8_t left, uint8_t right);

/* Exported functions prototypes */
/* ----------------------------- */
//void vfnCalibrateLinearCamera(void);
uint8_t ub_PowerOfTwo( uint8_t ub_x );
uint16_t getAbs(int16_t num);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */

/**************************************************************
 *  Name                 : 	vfn_saveLineCenterPosition
 *  Description          :	Store different reads of the line center in an array.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Store different reads of the line center in an array.
/////////////////////////////////////////////////////////////////////////
 void vfn_saveLineCenterPosition(void)
 {
	 uint8_t i;

	for(i = CAMERA_AVG; i > 0; i--)
	{
		ub_Line_Average[i] = ub_Line_Average[i-1];
	}	
 }
 
 /**************************************************************
 *  Name                 : 	vfn_detectLine
 *  Description          :	Try to detect the line or the goal.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Try to detect the line or the goal.
/////////////////////////////////////////////////////////////////////////
void vfn_detectLine(void)
{
	width = 0;
	center = 0;

	//Shifting to the right the array of line centers.
	vfn_saveLineCenterPosition();
	
	ub_IsGoal = 0;
	
	//Is it a goal?
	if( pat_info.value ==  GOAL && pat_info.valid == 7)
	{
		width = pat_info.width[3] - pat_info.width[2];
		center = width / 2 + pat_info.width[2];
		ub_IsGoal = 1;
		
		vfn_isValidLine( width, center, pat_info.width[2], pat_info.width[3] - 1);
	}//Is a line?
	else if( pat_info.value ==  BLACK_LINE && pat_info.valid == 3 )
	{
		width = pat_info.width[1] - pat_info.width[0];
		center = width / 2 + pat_info.width[0];
		
		vfn_isValidLine( width, center, pat_info.width[0], pat_info.width[1] - 1);
	}//Is a goal?
	else if( pat_info.value ==  GOAL_2 && pat_info.valid == 5 )
	{
		width = pat_info.width[2] - pat_info.width[1];
		center = width / 2 + pat_info.width[1];
		ub_IsGoal = 1;
		
		vfn_isValidLine( width, center, pat_info.width[1], pat_info.width[2] - 1);
	}
}

 /**************************************************************
 *  Name                 : 	vfn_isValidLine
 *  Description          :	Check if the line is a valid one and if it is, assign values.
 *  Parameters           :  [Input: ub_width, ub_center, ub_left ,ub_right, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Check if the line is a valid one and if it is, assign values.
/// \param ub_width width of the line.
/// \param ub_center center of the line.
/// \param ub_left left corner of the line.
/// \param ub_right right corner of the line.
/////////////////////////////////////////////////////////////////////////
void vfn_isValidLine(uint8_t ub_width, uint8_t ub_center, uint8_t ub_left, uint8_t ub_right)
{
	if( ( ( sb_BLACK_STRIP_WIDTH_MEASU - sb_RANGE ) <= ub_width ) && ( ( sb_BLACK_STRIP_WIDTH_MEASU + sb_RANGE ) >= ub_width ) )
	{
		ub_Black_Strip_Width = ub_width;
		
		ub_Line_Average[0] = ub_Black_Strip_Center = ub_center;
		
		ub_Left_Corner = ub_left;
		ub_Right_Corner = ub_right;
	}
	else
	{
		ub_IsGoal = 0;
	}
}

/**************************************************************
 *  Name                 : 	vfnProcess_Pixels
 *  Description          :	Process the pixels of the linear camera and detect the line
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Process the pixels of the linear camera and detect the line
/////////////////////////////////////////////////////////////////////////
void vfn_processPixels(void)
{	
	vfn_binarize();
	vfn_detectLine();
}

/**************************************************************
 *  Name                 : 	vfn_binarize
 *  Description          :	Create a pattern from the pixels.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Create a pattern from the pixels.
/////////////////////////////////////////////////////////////////////////
void vfn_binarize(void)
{
	uint8_t i = 0;
	uint8_t j = 0;
	uint8_t width = 0;
	
	pat_info.value = 0;
	pat_info.valid = 0;
	pat_info.width[j] = 0;
	
	uint8_t ub_currValue = 2;
	
	for( i = 0; i < NUM_PIXELS; i++)
	{	
		width++;
		
		if( LineScanImage0[i] > sw_Threshold && ub_currValue != 0 )
		{
			if( ub_currValue != 2 )
			{
				pat_info.width[j] = width - 1;
				j++;
			}
			
			pat_info.valid++;
			pat_info.value = pat_info.value << 1;
			
			ub_currValue = 0;
		}
		else if( LineScanImage0[i] < sw_Threshold && ub_currValue != 1 )
		{
			if( ub_currValue != 2 )
			{
				pat_info.width[j] = width - 1;
				j++;
			}
			
			pat_info.valid++;
			pat_info.value = pat_info.value << 1;
			pat_info.value |= 1;
			
			ub_currValue = 1;
		}
		
		if(LineScanImage0[i] > sw_Threshold)
		{
			ub_Bin_Pixels[i] = 0;
		}
		else
		{
			ub_Bin_Pixels[i] = 1;
		}
	}
	
	pat_info.width[j] = width;
}

/**************************************************************
 *  Name                 : 	vfn_calibrateLine
 *  Description          :	Measure the line in pixels
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Measure the line in pixels
/////////////////////////////////////////////////////////////////////////
void vfn_calibrateLine(void)
{
	//Create the pattern.
	vfn_binarize();
	
	//Is a black line?
	if( pat_info.value ==  BLACK_LINE && pat_info.valid == 3 )
	{
		ub_Left_Corner = pat_info.width[0];
		ub_Right_Corner = pat_info.width[1] - 1;
	
		sb_BLACK_STRIP_WIDTH_MEASU = ub_Black_Strip_Width = pat_info.width[1] - pat_info.width[0];
		ub_Black_Strip_Center = ub_Black_Strip_Width / 2 + pat_info.width[0];
	}
}

/**************************************************************
 *  Name                 : 	vfn_calibrateThreshold
 *  Description          :	Calculate the threshold automatically
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Calculate the threshold automatically
/////////////////////////////////////////////////////////////////////////
void vfn_calibrateThreshold(void)
{
	int16_t sw_tmp = 0;
	
	uint8_t i;
	
	sw_max = 0;
	sw_min = 1023;
	
	for( i = 0; i < NUM_PIXELS; i++)
	{
		if( LineScanImage0[i]  > sw_max )
		{
			sw_max = LineScanImage0[i];
		}
		
		if( LineScanImage0[i]  < sw_min )
		{
			sw_min = LineScanImage0[i];
		}
	}
	
	sw_tmp = sw_max - sw_min;
	
	sw_tmp = sw_tmp / 2;
	
	sw_Threshold = sw_tmp + sw_tmp / 2;
}

/* Exported functions */
/* ------------------ */


/**************************************************************
 *  Name                 :	ub_PowerOfTwo
 *  Description          :	Elevates 2 to the power of x
 *  Parameters           :  [Input: ub_x, Output, Input / output]
 *  Return               :	T_UBYTE
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Elevates 2 to the power of x
/// \param ub_x power of x
/// \return result
/////////////////////////////////////////////////////////////////////////
uint8_t ub_PowerOfTwo( uint8_t ub_x )
{
	uint8_t ub_y = 1;
	
	ub_x--;

	while( ub_x )
	{
		ub_y = ub_y << 1;
		ub_x--;
	}
	
	return ub_y;
}


/**************************************************************
 *  Name                 :	getAbs
 *  Description          :	Gets the absolute value of num.
 *  Parameters           :  [Input: sw_num, Output, Input / output]
 *  Return               :	uint16_t
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Gets the absolute value of num.
/// \param sw_num the number that you want to get its absolut.
/// \return the absolute number of sw_num
/////////////////////////////////////////////////////////////////////////
uint16_t getAbs(int16_t sw_num)
{
	int16_t const sw_mask = sw_num >> (sizeof(int16_t) * CHAR_BIT - 1);
  	return ((sw_num ^ sw_mask) - sw_mask);
}

/**************************************************************
 *  Name                 :	vfnCalibrateLinearCamera
 *  Description          :	Calibrate the Linear Camera.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Calibrate the Linear Camera.
/////////////////////////////////////////////////////////////////////////
/*void vfnCalibrateLinearCamera(void)
{
	static uint8_t ub_calibrationState = 0;
	
	switch(ub_calibrationState)
	{
		case 0:					
				if(Check_Btn_Press(BTN_3))
				{
					ub_calibrationState = 1;
					
					APPLeds_Led4_app();
				}
				else
				{
					vfn_calibrateThreshold();
				}
				
		break;
		
		case 1:
				if(Check_Btn_Press(BTN_3))
				{
					ub_calibrationState = 2;
					
					APPLeds_Led4_app();
				}
				else
				{
					vfn_calibrateLine();
				}
				
		break;
		
		case 2:
		
				//Do nothing
		
		break;
		
	}
}*/
