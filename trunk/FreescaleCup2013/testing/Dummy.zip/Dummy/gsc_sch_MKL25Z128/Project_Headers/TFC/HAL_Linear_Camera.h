/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            HAL_Linear_Camera.h
* version:         1.0
* %created_by:      Andres Torres Garcia %
* %date_created:    Tuesday August 04 01:19:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for uC Abstraction layer for ADC module          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 04/09/2013 |                   | Andres Torres     */
/*============================================================================*/

#ifndef HAL_LINEAR_CAMERA_H                               /* To avoid double inclusion */
#define HAL_LINEAR_CAMERA_H

/* Includes */
/* -------- */

/* Exported types and constants */
/* ---------------------------- */

#define NUM_PIXELS		128

/* Types definition */
/* typedef */

/*==================================================*/ 
/* Declaration of exported constants                */
/*==================================================*/


 
/* BYTE constants */

/* WORD constants */

/* LONG and STRUCTURE constants */


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTES */

extern volatile uint8_t  LineScanWorkingBuffer;
extern volatile uint8_t  LineScanImageReady;
extern volatile uint8_t  CurrentADC_State;

extern volatile uint16_t PotADC_Value[2];

extern volatile uint8_t CurrentLineScanPixel;
extern volatile uint8_t CurrentLineScanChannel;

/* WORDS */

extern volatile uint16_t  *LineScanImage0WorkingBuffer;
extern volatile uint16_t  *LineScanImage1WorkingBuffer;
extern volatile uint16_t  *LineScanImage0;
extern volatile uint16_t  *LineScanImage1;
extern volatile uint16_t  LineScanImage0Buffer[2][128];
extern volatile uint16_t  LineScanImage1Buffer[2][128];

extern volatile uint16_t BatSenseADC_Value;

/* LONGS and STRUCTURES */

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Functions prototypes */

extern void vfnInitCamera(void);
extern void vfnStopCamera(void);
extern void vfnStartCamera(void);
extern void vfnStartCapturing(void);
extern void vfnStopCapturing(void);
extern void vfnCapturePixels(void);

extern void TFC_SetLineScanExposureTime(uint32_t  TimeIn_uS);
extern float TFC_ReadPot(uint8_t Channel);
extern float TFC_ReadBatteryVoltage(void);


/* Functions macros */

#define TAOS_CLK_HIGH  GPIOE_PSOR = (1<<1)  
#define TAOS_CLK_LOW   GPIOE_PCOR = (1<<1)  
#define TAOS_SI_HIGH   GPIOD_PSOR = (1<<7)
#define TAOS_SI_LOW    GPIOD_PCOR =	(1<<7)

/* Exported defines */

/**
 * \defgroup eMIOS channels and pins used by the camera.
 * @{
 */
#define CHANNEL_CK                      5
#define CHANNEL_CNT_CK          23
#define PIN_CK                          pin_PB13


#define CHANNEL_SI              3
#define CHANNEL_CNT_SI          0
#define PIN_SI                          pin_PB11

#define CHANNEL_TRIG            11
#define CHANNEL_CNT_TRIG        8
#define PIN_TRIG                        pin_PA11

#define CHANNEL_TRIG_ADC                2
#define CHANNEL_CNT_TRIG_ADC    23
#define PIN_TRIG_ADC                    pin_PA2

#define CLK_PERIOD      40
#define SI_PERIOD       20000

/**@}*/

#define ADC_STATE_INIT							0
#define ADC_STATE_CAPTURE_POT_0			        1
#define ADC_STATE_CAPTURE_POT_1			        2
#define ADC_STATE_CAPTURE_BATTERY_LEVEL			3
#define ADC_STATE_CAPTURE_LINE_SCAN		        4

#endif
