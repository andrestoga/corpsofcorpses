/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Include:        %APP_Algorithm.h%
* Instance:         RPL_1
* %version:         1.1 %
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Friday Oct 26 17:00:01 2012 %
*=============================================================================*/
/* DESCRIPTION : Header file for the app layer of the algorith           */
/*============================================================================*/
/* FUNCTION COMMENT : Contains functions to control the	  */	
/*  Freescale car.												              */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 25/05/2012  | 				               | Oscar Rodea      */
/* Integration under Continuus CM                                             */
/*============================================================================*/

#ifndef APP_ALGORITHM_H                               /* To avoid double inclusion */
#define APP_ALGORITHM_H

/* Includes */
/* -------- */


/* Exported types and constants */
/* ---------------------------- */

/* Types definition */
/* typedef */

/*==================================================*/ 
/* Declaration of exported constants                */
/*==================================================*/ 
/* BYTE constants */

/** \brief The center of the black line */


/* WORD constants */

/* LONG and STRUCTURE constants */


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 
/* BYTES */

/* WORDS */

/* LONGS and STRUCTURES */

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Functions prototypes */

/*! First version of the algorithm	
*/
extern void vfnSecondVersion(void);

/* Functions macros */

/* Exported defines */


#endif


