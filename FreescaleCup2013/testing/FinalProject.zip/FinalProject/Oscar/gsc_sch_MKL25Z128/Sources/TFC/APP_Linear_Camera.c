/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:         %APP_Linear_Camera.c%
* Instance:         RPL_1
* %version:         1.2 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : C source file for the application layer of the Linear Camera */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the declarations and definitions of  */
/*					  the variables, and functions of the application layer of*/													  
/*					  the camera.											  */ 
/*					  	  											  		  */
/* 					                      									  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  |                               | Andres Torres    */
/*  1.1      | 04/10/2012  |                               | Andres Torres    */
/*  1.2      | 07/10/2012  |                               | Andres Torres    */
/*  1.3      | 13/11/2012  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/* LONG and STRUCTURE constants */

/*!
  \def CHAR_BIT
  Useful for the function getAbs
*/
#define CHAR_BIT 			8

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 

/** \brief Tolerance range for the width of the line */
const int8_t sb_RANGE = 4;

/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/

/** \brief Width of the black line */
uint8_t ub_Black_Strip_Width = 0;

uint8_t ub_Black_Strip_Width2 = 0;

/** \brief The center of the black line */
uint8_t ub_Black_Strip_Center = 0;

uint8_t ub_Black_Strip_Center2 = 0;

uint8_t CameraAvg = 1;

/** \brief Array of line centers. */
uint8_t ub_Line_Average[20];

uint8_t ub_Line_Average2[20];

extern volatile uint16_t  *LineScanImage0;

uint16_t MaxSlopeMag = 300;

/** \brief Calibrate value of the width of the line. */
int8_t sb_BLACK_STRIP_WIDTH_MEASU = 0;

uint8_t width = 0;
uint8_t center = 0;

uint8_t width2 = 0;
uint8_t center2 = 0;

volatile uint8_t FailCamLectCounter = 0;
volatile uint8_t FailCamLectCounter2 = 0;

volatile uint8_t SuccCamLecturesCounter = 0;
volatile uint8_t SuccCamLecturesCounter2 = 0;

int16_t uw_CentralDifferentials [300];
int16_t uw_CentralDifferentials2 [300];

uint16_t ArrayOfLines [6];

uint8_t lineWidth = 0;
uint8_t lineCenter = 0;

uint8_t goalCounter = 0;

uint8_t GoalDetector = 0;
uint8_t GoalDetector2 = 0;

uint8_t IsGoalDetected = 0;
uint8_t IsGoalDetected2 = 0;

int8_t sb_BLACK_STRIP_WIDTH_MEASU2 = 0;
uint16_t ArrayOfLines2 [6];

uint8_t lineWidth2 = 0;
uint8_t lineCenter2 = 0;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */
void vfn_calibrateLine(void);

void CalculateCentralDifferentials(int max);
uint8_t Get_Lowest_Highest_Values(uint8_t max);
void vfn_ProcessPixels_V2();
uint8_t FoundLastGreater(uint8_t firstGreater, uint8_t max);
uint8_t Identify(uint8_t max);

void CalculateCentralDifferentials2(int max);
uint8_t FoundLastGreater2(uint8_t firstGreater, uint8_t max);
uint8_t Get_Lowest_Highest_Values2(uint8_t max);
uint8_t Identify2(uint8_t max);

/* Exported functions prototypes */
/* ----------------------------- */
void vfn_saveLineCenterPosition(void);
void vfn_saveLineCenterPosition2(void);
uint16_t getAbs(int16_t num);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */

/**************************************************************
 *  Name                 :	getAbs
 *  Description          :	Gets the absolute value of num.
 *  Parameters           :  [Input: sw_num, Output, Input / output]
 *  Return               :	uint16_t
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Gets the absolute value of num.
/// \param sw_num the number that you want to get its absolut.
/// \return the absolute number of sw_num
/////////////////////////////////////////////////////////////////////////
uint16_t getAbs(int16_t sw_num)
{
	int16_t const sw_mask = sw_num >> (sizeof(int16_t) * CHAR_BIT - 1);
  	return ((sw_num ^ sw_mask) - sw_mask);
}

uint8_t FoundLastGreater2(uint8_t firstGreater, uint8_t max)
{
	uint8_t lastGreater = firstGreater;

	do
	{
		lastGreater++;

	} while (uw_CentralDifferentials2[lastGreater] > MaxSlopeMag && lastGreater < max);

	lastGreater--;

	return lastGreater;
}

uint8_t Identify(uint8_t max)
{
	uint16_t i;
	uint8_t k;

	uint8_t toggleNegPos = 1;
	uint8_t lineCounter = 0;

	int16_t tmpLeft = -1;
	int16_t tmpRight = -1;

	uint8_t inPos = 0;
	uint8_t countTrans = 0;

	for (i = 0, k = 0; i < max; i++)
	{
		if (uw_CentralDifferentials[i] > 0)
		{
			inPos = 1;

			if (uw_CentralDifferentials[i] >= MaxSlopeMag && toggleNegPos == 0)
			{
				toggleNegPos = 1;

				tmpRight = FoundLastGreater(i, max);
				
				ArrayOfLines[k] = tmpLeft;
				ArrayOfLines[k + 1] = tmpRight;
				k += 2;
				lineCounter++;

				tmpLeft = tmpRight = -1;

				countTrans = 0;
			}
		}
		else if (uw_CentralDifferentials[i] != 0)
		{
			if (tmpLeft != -1 && inPos)
			{
				countTrans++;

				if (uw_CentralDifferentials[i + 1] < 0 && countTrans > 2)
				{
					toggleNegPos = 1;
					tmpLeft = -1;

					countTrans = 0;
				}
			}

			inPos = 0;

			if (uw_CentralDifferentials[i] <= -MaxSlopeMag && toggleNegPos == 1)
			{
				toggleNegPos = 0;

				tmpLeft = i;
			}
		}
	}

	//Calculate the width  and the center of the line
	switch (lineCounter)
	{
		//It's a black line
		case 1:

			lineWidth = ArrayOfLines[1] - ArrayOfLines[0];
			lineCenter = ArrayOfLines[0] + (lineWidth / 2);

			return 1;

		//It's not a valid line
		default:

			return 0;
	}
}

uint8_t Identify2(uint8_t max)
{
	uint16_t i;
	uint8_t k;

	uint8_t toggleNegPos = 1;
	uint8_t lineCounter = 0;

	int16_t tmpLeft = -1;
	int16_t tmpRight = -1;

	uint8_t inPos = 0;
	uint8_t countTrans = 0;

	for (i = 0, k = 0; i < max; i++)
	{
		if (uw_CentralDifferentials2[i] > 0)
		{
			inPos = 1;

			if (uw_CentralDifferentials2[i] >= MaxSlopeMag && toggleNegPos == 0)
			{
				toggleNegPos = 1;

				tmpRight = FoundLastGreater2(i, max);
				
				ArrayOfLines2[k] = tmpLeft;
				ArrayOfLines2[k + 1] = tmpRight;
				k += 2;
				lineCounter++;

				tmpLeft = tmpRight = -1;

				countTrans = 0;
			}
		}
		else if (uw_CentralDifferentials2[i] != 0)
		{
			if (tmpLeft != -1 && inPos)
			{
				countTrans++;

				if (uw_CentralDifferentials2[i + 1] < 0 && countTrans > 2)
				{
					toggleNegPos = 1;
					tmpLeft = -1;

					countTrans = 0;
				}
			}

			inPos = 0;

			if (uw_CentralDifferentials2[i] <= -MaxSlopeMag && toggleNegPos == 1)
			{
				toggleNegPos = 0;

				tmpLeft = i;
			}
		}
	}

	//Calculate the width  and the center of the line
	switch (lineCounter)
	{
		//It's a black line
		case 1:

			lineWidth2 = ArrayOfLines2[1] - ArrayOfLines2[0];
			lineCenter2 = ArrayOfLines2[0] + (lineWidth2 / 2);

			return 1;

		//It's not a valid line
		default:

			return 0;
	}
}

uint8_t FoundLastGreater(uint8_t firstGreater, uint8_t max)
{
	uint8_t lastGreater = firstGreater;

	do
	{
		lastGreater++;

	} while (uw_CentralDifferentials[lastGreater] > MaxSlopeMag && lastGreater < max);

	lastGreater--;

	return lastGreater;
}

void vfn_ProcessPixels_V2()
{
	CalculateCentralDifferentials(NUM_PIXELS);
	CalculateCentralDifferentials2(NUM_PIXELS);
	
	IsGoalDetected = 0;
	IsGoalDetected2 = 0;
	
	switch (Get_Lowest_Highest_Values(NUM_PIXELS))
	{
		case 1:
			
			ub_Black_Strip_Width = lineWidth;
			ub_Line_Average[0] = ub_Black_Strip_Center = lineCenter;
			
			if (GoalDetector >= 3)
			{
				IsGoalDetected = 1;
			}
			
			break;
			
		case 2:
			
			ub_Black_Strip_Width = lineWidth;
			ub_Line_Average[0] = ub_Black_Strip_Center = lineCenter;
			
			IsGoalDetected = 1;
			
			break;
			
		default:
			
			if (GoalDetector >= 3)
			{
				IsGoalDetected = 1;
			}
			
			break;
	}
	
	switch (Get_Lowest_Highest_Values2(NUM_PIXELS))
	{
			case 1:
				
				ub_Black_Strip_Width2 = lineWidth2;
				ub_Line_Average2[0] = ub_Black_Strip_Center2 = lineCenter2;
				
				if (GoalDetector2 >= 3)
				{
					IsGoalDetected2 = 1;
				}
				
				break;
				
			case 2:
				
				ub_Black_Strip_Width = lineWidth;
				ub_Line_Average[0] = ub_Black_Strip_Center = lineCenter;
				
				IsGoalDetected2 = 1;
				
				break;
				
			default:
				
				if (GoalDetector2 >= 3)
				{
					IsGoalDetected2 = 1;
				}
				
				break;
		}
}

/**************************************************************
 *  Name                 : 	vfn_saveLineCenterPosition
 *  Description          :	Store different reads of the line center in an array.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Store different reads of the line center in an array.
/////////////////////////////////////////////////////////////////////////

void CalculateCentralDifferentials(int max)
{
	int i;

	uw_CentralDifferentials[0] = (LineScanImage0[1] - LineScanImage0[0]) / 2;
	uw_CentralDifferentials[max - 1] = (LineScanImage0[max - 1] - LineScanImage0[max - 2]) / 2;

	for (i = 1; i < max - 1; i++)
	{
		uw_CentralDifferentials[i] = (LineScanImage0[i + 1] - LineScanImage0[i - 1]) / 2;
	}
}

void CalculateCentralDifferentials2(int max)
{
	int i;

	uw_CentralDifferentials2[0] = (LineScanImage1[1] - LineScanImage1[0]) / 2;
	uw_CentralDifferentials2[max - 1] = (LineScanImage1[max - 1] - LineScanImage1[max - 2]) / 2;

	for (i = 1; i < max - 1; i++)
	{
		uw_CentralDifferentials2[i] = (LineScanImage1[i + 1] - LineScanImage1[i - 1]) / 2;
	}
}

//TODO: Set the value of Oscar
uint8_t Get_Lowest_Highest_Values2(uint8_t max)
{
	uint16_t i;
	uint8_t k;

	uint8_t toggleNegPos = 1;
	uint8_t lineCounter = 0;

	int16_t tmpLeft = -1;
	int16_t tmpRight = -1;

	uint8_t inPos = 0;
	uint8_t countTrans = 0;
	
	GoalDetector2 = 0;

	for (i = 0, k = 0; i < max; i++)
	{
		if (uw_CentralDifferentials2[i] > 0)
		{
			inPos = 1;

			if (uw_CentralDifferentials2[i] >= MaxSlopeMag && toggleNegPos == 0)
			{
				toggleNegPos = 1;

				tmpRight = FoundLastGreater2(i, max);
				
				GoalDetector2++;
				
				if (TFC_GetDIP_Switch() & 2)
				{
					if( ( ( sb_BLACK_STRIP_WIDTH_MEASU2 - sb_RANGE ) <= ( tmpRight - tmpLeft ) ) && ( ( sb_BLACK_STRIP_WIDTH_MEASU2 + sb_RANGE ) >= ( tmpRight - tmpLeft ) ) )
					{
						ArrayOfLines2[k] = tmpLeft;
						ArrayOfLines2[k + 1] = tmpRight;
						k += 2;
						lineCounter++;

						tmpLeft = tmpRight = -1;

						countTrans = 0;
					}
				}
				else
				{
					if ((tmpRight - tmpLeft) > 3)
					{
						ArrayOfLines2[k] = tmpLeft;
						ArrayOfLines2[k + 1] = tmpRight;
						k += 2;
						lineCounter++;

						tmpLeft = tmpRight = -1;

						countTrans = 0;
					}
				}
			}
		}
		else if (uw_CentralDifferentials2[i] != 0)
		{
			if (tmpLeft != -1 && inPos)
			{
				countTrans++;

				if (uw_CentralDifferentials2[i + 1] < 0 && countTrans > 2)
				{
					toggleNegPos = 1;
					tmpLeft = -1;

					countTrans = 0;
				}
			}

			inPos = 0;

			if (uw_CentralDifferentials2[i] <= -MaxSlopeMag && toggleNegPos == 1)
			{
				toggleNegPos = 0;

				tmpLeft = i;
			}
		}
	}
	
	FailCamLectCounter2 = 0;

	//Calculate the width  and the center of the line
	switch (lineCounter)
	{
		//It's a black line
		case 1:

			lineWidth2 = ArrayOfLines2[1] - ArrayOfLines2[0];
			lineCenter2 = ArrayOfLines2[0] + (lineWidth2 / 2);
			
			SuccCamLecturesCounter2++;

			return 1;

		//It's a goal
		case 3:

			lineWidth2 = ArrayOfLines2[3] - ArrayOfLines2[2];
			lineCenter2 = ArrayOfLines2[2] + (lineWidth2 / 2);
			
			SuccCamLecturesCounter2++;

			//Stop the car!!!

			return 2;

		//It's not a valid line
		default:
			
			FailCamLectCounter2++;

			return 0;
	}
}

//TODO: Set the value of Oscar
uint8_t Get_Lowest_Highest_Values(uint8_t max)
{
	uint16_t i;
	uint8_t k;

	uint8_t toggleNegPos = 1;
	uint8_t lineCounter = 0;

	int16_t tmpLeft = -1;
	int16_t tmpRight = -1;

	uint8_t inPos = 0;
	uint8_t countTrans = 0;
	
	GoalDetector = 0;

	for (i = 0, k = 0; i < max; i++)
	{
		if (uw_CentralDifferentials[i] > 0)
		{
			inPos = 1;

			if (uw_CentralDifferentials[i] >= MaxSlopeMag && toggleNegPos == 0)
			{
				toggleNegPos = 1;

				tmpRight = FoundLastGreater(i, max);
				
				GoalDetector++;

				if (TFC_GetDIP_Switch() & 2)
				{
					if( ( ( sb_BLACK_STRIP_WIDTH_MEASU - sb_RANGE ) <= ( tmpRight - tmpLeft ) ) && ( ( sb_BLACK_STRIP_WIDTH_MEASU + sb_RANGE ) >= ( tmpRight - tmpLeft ) ) )
					{
						ArrayOfLines[k] = tmpLeft;
						ArrayOfLines[k + 1] = tmpRight;
						k += 2;
						lineCounter++;

						tmpLeft = tmpRight = -1;

						countTrans = 0;
					}
				}
				else
				{	
					if ((tmpRight - tmpLeft) > 3)
					{
						ArrayOfLines[k] = tmpLeft;
						ArrayOfLines[k + 1] = tmpRight;
						k += 2;
						lineCounter++;

						tmpLeft = tmpRight = -1;

						countTrans = 0;
					}
				}
			}
		}
		else if (uw_CentralDifferentials[i] != 0)
		{
			if (tmpLeft != -1 && inPos)
			{
				countTrans++;

				if (uw_CentralDifferentials[i + 1] < 0 && countTrans > 2)
				{
					toggleNegPos = 1;
					tmpLeft = -1;

					countTrans = 0;
				}
			}

			inPos = 0;

			if (uw_CentralDifferentials[i] <= -MaxSlopeMag && toggleNegPos == 1)
			{
				toggleNegPos = 0;

				tmpLeft = i;
			}
		}
	}
	
	FailCamLectCounter = 0;

	//Calculate the width  and the center of the line
	switch (lineCounter)
	{
		//It's a black line
		case 1:

			lineWidth = ArrayOfLines[1] - ArrayOfLines[0];
			lineCenter = ArrayOfLines[0] + (lineWidth / 2);
			
			SuccCamLecturesCounter++;

			return 1;

		//It's a goal
		case 3:

			lineWidth = ArrayOfLines[3] - ArrayOfLines[2];
			lineCenter = ArrayOfLines[2] + (lineWidth / 2);
			
			SuccCamLecturesCounter++;

			//Stop the car!!!

			return 2;

		//It's not a valid line
		default:
			
			FailCamLectCounter++;

			return 0;
	}
}

 void vfn_saveLineCenterPosition(void)
 {
	 uint8_t i;

	for(i = CameraAvg - 1; i > 0; i--)
	{
		ub_Line_Average[i] = ub_Line_Average[i-1];
	}	
 }
 
 void vfn_saveLineCenterPosition2(void)
 {
	 uint8_t i;

	for(i = CameraAvg - 1; i > 0; i--)
	{
		ub_Line_Average2[i] = ub_Line_Average2[i-1];
	}	
 }
 
/**************************************************************
 *  Name                 : 	vfn_calibrateLine
 *  Description          :	Measure the line in pixels
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Measure the line in pixels
/////////////////////////////////////////////////////////////////////////
void vfn_calibrateLine(void)
{	
	CalculateCentralDifferentials(NUM_PIXELS);
	CalculateCentralDifferentials2(NUM_PIXELS);
		
	switch (Identify(NUM_PIXELS)) {
	
		case 1:
			
			sb_BLACK_STRIP_WIDTH_MEASU = ub_Black_Strip_Width = lineWidth;
			ub_Line_Average[0] = ub_Black_Strip_Center = lineCenter;
			
			break;
			
		default:
			break;
	}
	
	switch (Identify2(NUM_PIXELS)) {
		
			case 1:
				
				sb_BLACK_STRIP_WIDTH_MEASU2 = ub_Black_Strip_Width2 = lineWidth2;
				ub_Line_Average2[0] = ub_Black_Strip_Center2 = lineCenter2;
				
				break;
				
			default:
				break;
		}
}
