#ifndef TFC_TYPES_H_
#define TFC_TYPES_H_

#define TRUE 	1
#define FALSE  0


#endif /* TFC_TYPES_H_ */
