#include "derivative.h" /* include peripheral declarations */
#include "TFC\TFC.h"

int main(void)
{
	uint32_t i = 0;
	
	TFC_Init();
	
	for(;;)
	{	   
		//TFC_Task must be called in your main loop.  This keeps certain processing happy (I.E. Serial port queue check)
		TFC_Task();
							
		if(TFC_Ticker[0]>100 && LineScanImageReady==1)
		{
			
			TFC_Ticker[0] = 0;
			LineScanImageReady=0;
			
			(*ptrFctnMachineState[en_State])();
			
			 TERMINAL_PRINTF("\r\n");
			 TERMINAL_PRINTF("%d ", pat_info.value);
			 TERMINAL_PRINTF("%d ", pat_info.valid);
			 TERMINAL_PRINTF("%d ", ub_Black_Strip_Center);
			 TERMINAL_PRINTF("%d ", ub_Black_Strip_Width);
			 TERMINAL_PRINTF("\r\n");
			 
			 for(i = 0;i < 128;i++)
			 {
				 TERMINAL_PRINTF("%d",ub_Bin_Pixels[i]);
			 }
			 
			 TERMINAL_PRINTF("\r\n");
			 
//			if(t==0)
//				t=3;
//			else
//				t--;
//			
//			TFC_SetBatteryLED_Level(t);
			 
			 //****************************************************
			
//			 TERMINAL_PRINTF("\r\n");
//			 TERMINAL_PRINTF("L:");
//				
//			 for(i=0;i<128;i++)
//			 {
//				 TERMINAL_PRINTF("%X,",LineScanImage0[i]);
//			 }
//			
//			 for(i=0;i<128;i++)
//			 {
//				 TERMINAL_PRINTF("%X",LineScanImage1[i]);
//				 
//				 if(i==127)
//					 TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
//				 else
//					 TERMINAL_PRINTF(",",LineScanImage1[i]);
//			}
			 
			 //****************************************************
			 
//			 vfn_processPixels();
//			 
//			 TERMINAL_PRINTF("\r\n");
//			 TERMINAL_PRINTF("%d ", pat_info.value);
//			 TERMINAL_PRINTF("%d ", pat_info.valid);
//			 TERMINAL_PRINTF("%d ", center);
//			 TERMINAL_PRINTF("%d ", width);
//			 TERMINAL_PRINTF("%d ", pat_info.width[0]);
//			 TERMINAL_PRINTF("%d ", pat_info.width[1]);
//			 TERMINAL_PRINTF("%d", pat_info.width[2]);
//			 TERMINAL_PRINTF("\r\n");
//			 
//			 for(i = 0;i < 128;i++)
//			 {
//				 TERMINAL_PRINTF("%d",ub_Bin_Pixels[i]);
//			 }
//			 
//			 TERMINAL_PRINTF("\r\n");
			 
//			 for(i=0;i<128;i++)
//			 {
//				 TERMINAL_PRINTF("%X,",LineScanImage0[i]);
//			 }
//			 
//			 TERMINAL_PRINTF("\r\n");
			 
			 //****************************************************
				 
		}//End if
			
			
			
//			 TFC_Ticker[0] = 0;
//			 LineScanImageReady=0;
//			 
//				if(t==0)
//					t=3;
//				else
//					t--;
//				
//				 TFC_SetBatteryLED_Level(t);
//				 
//				 TERMINAL_PRINTF("\r\n");
//				 
//				 for(i=0;i<128;i++)
//				 {
//					 
//					 TERMINAL_PRINTF("%X, ", LineScanImage0[i]);
//					 
//					 /*if (LineScanImage0[i] > 2000) {
//						TERMINAL_PRINTF("%d", 0);
//					} else {
//						TERMINAL_PRINTF("%d", 1);
//					}*/
//				 }
//				 
//				 TERMINAL_PRINTF("\r\n");

			//This Demo program will look at the middle 2 switch to select one of 4 demo modes.
			//Let's look at the middle 2 switches
			/*switch((TFC_GetDIP_Switch()>>1)&0x03)
			{
			default:
			case 0 :
				//Demo mode 0 just tests the switches and LED's
				if(TFC_PUSH_BUTTON_0_PRESSED)
					TFC_BAT_LED0_ON;
				else
					TFC_BAT_LED0_OFF;
				
				if(TFC_PUSH_BUTTON_1_PRESSED)
					TFC_BAT_LED3_ON;
				else
					TFC_BAT_LED3_OFF;
				
				
				if(TFC_GetDIP_Switch()&0x01)
					TFC_BAT_LED1_ON;
				else
					TFC_BAT_LED1_OFF;
				
				if(TFC_GetDIP_Switch()&0x08)
					TFC_BAT_LED2_ON;
				else
					TFC_BAT_LED2_OFF;
				
				break;
					
			case 1:
				
				//Demo mode 1 will just move the servos with the on-board potentiometers
				if(TFC_Ticker[0]>=20)
				{
					TFC_Ticker[0] = 0; //reset the Ticker
					//Every 20 mSeconds, update the Servos
					TFC_SetServo(0,TFC_ReadPot(0));
					TFC_SetServo(1,TFC_ReadPot(1));
				}
				//Let's put a pattern on the LEDs
				if(TFC_Ticker[1] >= 125)
				{
					TFC_Ticker[1] = 0;
					t++;
					if(t>4)
					{
						t=0;
					}			
					TFC_SetBatteryLED_Level(t);
				}
				
				TFC_SetMotorPWM(0,0); //Make sure motors are off
				TFC_HBRIDGE_DISABLE;
			

				break;
				
			case 2 :
				
				//Demo Mode 2 will use the Pots to make the motors move
				TFC_HBRIDGE_ENABLE;
				TFC_SetMotorPWM(TFC_ReadPot(0),TFC_ReadPot(1));
						
				//Let's put a pattern on the LEDs
				if(TFC_Ticker[1] >= 125)
					{
						TFC_Ticker[1] = 0;
							t++;
							if(t>4)
							{
								t=0;
							}			
						TFC_SetBatteryLED_Level(t);
					}
				break;
			
			case 3 :
			
				//Demo Mode 3 will be in Freescale Garage Mode.  It will beam data from the Camera to the 
				//Labview Application
				
		
				if(TFC_Ticker[0]>100 && LineScanImageReady==1)
					{
					 TFC_Ticker[0] = 0;
					 LineScanImageReady=0;
					 TERMINAL_PRINTF("\r\n");
					 TERMINAL_PRINTF("L:");
					 
					 	if(t==0)
					 		t=3;
					 	else
					 		t--;
					 	
						 TFC_SetBatteryLED_Level(t);
						
						 for(i=0;i<128;i++)
						 {
								 TERMINAL_PRINTF("%X,",LineScanImage0[i]);
						 }
						
						 for(i=0;i<128;i++)
						 {
								 TERMINAL_PRINTF("%X",LineScanImage1[i]);
								 if(i==127)
									 TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
								 else
									 TERMINAL_PRINTF(",",LineScanImage1[i]);
						}										
							
					}
					


				break;
			}*/
	}//End for
	
	return 0;
}//End main
