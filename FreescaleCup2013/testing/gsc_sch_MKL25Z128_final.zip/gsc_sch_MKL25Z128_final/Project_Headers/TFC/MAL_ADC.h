/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            MAL_ADC.h
* version:         1.0
* %created_by:      Andres Torres Garcia %
* %date_created:    Wednesday August 04 12:05:01 2013 %
*=============================================================================*/
/* DESCRIPTION :          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 04/09/2013 |                   | Andres Torres     */
/*============================================================================*/

#ifndef MAL_ADC_H                               /* To avoid double inclusion */
#define MAL_ADC_H

/* Includes */
/* -------- */
/* Register definitions for selected microcontroller */
#include "TFC\TFC.h"

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Exported defines */

#define ADC_MAX_CODE    (4095)

#define TFC_POT_0_ADC_CHANNEL		13
#define TFC_POT_1_ADC_CHANNEL		12
#define TFC_BAT_SENSE_CHANNEL		4
#define TFC_LINESCAN0_ADC_CHANNEL	6
#define TFC_LINESCAN1_ADC_CHANNEL	7

/* Exported functions */
//void TFC_InitADCs();
extern void InitADC0(void);

//void PIT0_IRQ(void);
//void ADC0_IRQ(void);
//
//float TFC_ReadPot(uint8_t Channel);
float MAL_ReadPot(uint8_t Channel);
//float TFC_ReadBatteryVoltage(void);

#endif
