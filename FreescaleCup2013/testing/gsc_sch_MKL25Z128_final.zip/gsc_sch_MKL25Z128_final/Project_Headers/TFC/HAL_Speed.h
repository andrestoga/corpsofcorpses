/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            HAL_Motors.h
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Tuesday October 10 13:05:01 2013 %
*=============================================================================*/
/* DESCRIPTION :          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 15/10/2013 |                   | Oscar Rodea       */
/*============================================================================*/

#ifndef HAL_SPEED_H_
#define HAL_SPEED_H_

/* Register definitions for selected microcontroller */
#include "TFC\TFC.h"


void HAL_SetSpeed(float right_speed, float left_speed);
float HAL_GetSpeed(uint8_t channel);
void HAL_ControlSpeed(void);
void HAL_SimpleControl(void);
void HAL_PID(void);
void HAL_ResetPID_Values(void);
void HAL_ProcessSpeed(uint16_t counts, uint8_t channel);
void HAL_InitSpeedSensor(void);

#endif /* HAL_SPEED_H_ */
