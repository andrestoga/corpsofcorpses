/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            Interruptions.h
* version:         1.0
* %created_by:      Andres Torres Garcia %
* %date_created:    Friday Sep 27 00:53:01 2013 %
*=============================================================================*/
/* DESCRIPTION :          */
/*============================================================================*/
/* FUNCTION COMMENT :                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 27/09/2013 |                   | Andres Torres     */
/*============================================================================*/

#ifndef INTERRUPTIONS_H                               /* To avoid double inclusion */
#define INTERRUPTIONS_H

/* Includes */
/* -------- */
/* Register definitions for selected microcontroller */
#include "TFC\TFC.h"

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Exported functions prototypes and macros */
/* ---------------------------------------- */

/* Exported defines */

/* Exported functions */

extern void PIT0_IRQ(void);
extern void ADC0_IRQ(void);

#endif
