/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:         %APP_Machine_State.c%
* Instance:         RPL_1
* %version:         1.0 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : C source file for the machine state.                         */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the function and variable definitions*/
/*					  of the machine state                                    */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/

/** \brief Pointer to function for the machine state. */
void (*ptrFctnMachineState[NUM_STATES]) (void);

/** \brief State of the machine state. */
enum STATE en_State = FIRST_STATE;

/** \brief Variable used to toggle the state of the back wheels. */
static uint8_t toggle = 1;

uint32_t i = 0;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */

void vfnFirstState(void);
void vfnSecondState(void);
void vfnThirdState(void);
void vfnFourState(void);

/* Exported functions prototypes */
/* ----------------------------- */

void vfnInitStates(void);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */
/**************************************************************
 *  Name                 : vfnFirstState
 *  Description          : The first state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The first state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnFirstState(void)
{	
	//Turn on led 1
	TFC_BAT_LED0_ON;

	if(Check_Btn_Press(BTN_0))
	{
		en_State = SECOND_STATE;
		
		TFC_BAT_LED0_OFF;
		TFC_BAT_LED1_ON;
	}
}

/**************************************************************
 *  Name                 : vfnSecondState
 *  Description          :	The second state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The second state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnSecondState(void)
{
	if(Check_Btn_Press(BTN_0))
	{
		en_State = THIRD_STATE;
	
		TFC_BAT_LED1_OFF;
		TFC_BAT_LED2_ON;
	}
	
	if(LineScanImageReady==1)
	 {
		LineScanImageReady=0;
		
		vfn_calibrateLine();
	 }
}

/**************************************************************
 *  Name                 : vfnThirdState
 *  Description          : The third state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The third state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnThirdState(void)
{
	if(Check_Btn_Press(BTN_0))
	{
		en_State = FOUR_STATE;
		
		TFC_BAT_LED2_OFF;
		TFC_BAT_LED3_ON;
		
		TFC_BAT_LED0_ON;
	}
}

/**************************************************************
 *  Name                 : vfnFourState
 *  Description          : The four state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The four state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnFourState(void)
{
	static uint8_t numLed = 0;
	
	if(Check_Btn_Press(BTN_0))
	{	
		if(toggle)
		{
			toggle = 0;
			TFC_HBRIDGE_DISABLE;
		}
		else
		{
			toggle = 1;
			TFC_HBRIDGE_ENABLE;
			HAL_ResetPID_Values();		//Reset PID values
			ResetGoal();				//Reset goal values
		}
	}
	
	vfn_saveLineCenterPosition();
	vfn_saveLineCenterPosition2();
	
	if(LineScanImageReady==1)
	 {
		LineScanImageReady=0;
		
		vfn_ProcessPixels_V2();
	}
	
	//Algorithms
	if (TFC_GetDIP_Switch() & 2)
	{
		vfnSecondVersion();
	}
	else
	{
		//Oscar's Algorithm
		vfnAlgorithmsORA();
	}
	
	//Goal
	
	if (TFC_GetDIP_Switch() & 0x01) {
		TimerGoal();
		vfnMachineStateGoal();
	}
	
}

/* Exported functions */
/* ------------------ */

/**************************************************************
 *  Name                 : vfnInitStates
 *  Description          : Initialize the pointer to function states.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Initialize the pointer to function states.
/////////////////////////////////////////////////////////////////////////
void vfnInitStates(void)
{
	ptrFctnMachineState[0] = &vfnFirstState;
	ptrFctnMachineState[1] = &vfnSecondState;
	ptrFctnMachineState[2] = &vfnThirdState;
	ptrFctnMachineState[3] = &vfnFourState;
}
