/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for algorithms by Oscar									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the algorithms			  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"

#define CENTER_LINE		63
#define WHEEL_RIGHT		0
#define WHEEL_LEFT		1

/* Machine State */
#define CENTRO_STATE	1
#define MEDIO_STATE		2
#define ALTO_STATE		3
#define EXTREMO_STATE	4

#define CENTRO_LINEA	25
#define MEDIO_LINEA_L	25
#define MEDIO_LINEA_H	50
#define ALTO_LINEA_L	25
#define ALTO_LINEA_H	55
#define EXTREMO_LINEA	40

#define CENTRO_STEERING_COEFF	65
#define MEDIO_STEERING_COEFF	45
#define ALTO_STEERING_COEFF		35
#define EXTREMO_STEERING_COEFF	35

#define CENTRO_SPEED_COEFF	0
#define MEDIO_SPEED_COEFF	0.05
#define ALTO_SPEED_COEFF	0.13
#define EXTREMO_SPEED_COEFF	0.18

/* Machine Goal */
#define LOOK_FOR_STATE		0
#define WAIT_TIME_STATE		1
#define FINISH_STATE		2
#define TIME_WAIT			200		//x*(10ms)
#define GOALS_ALLOWED		2		

uint8_t collision_flag = 0;
uint8_t collision_flag2 = 0;

/* Machine State Variables*/
uint8_t MachineState_state = CENTRO_STATE;
float centro_speed = 0.45;
float medio_speed = 0.33;
float alto_speed = 0.31;
float extremo_speed = 0.24;

/* Machine State Variables*/
uint8_t MachineGoal_state = LOOK_FOR_STATE;
uint8_t Goal_Counter = 0;				//Quantity of goals
uint8_t Timer_Goal = 0;					//Time in wait state

void vfnAlgorithmsORA(void){
//	float pot_0, pot_1;
	int8_t ub_center_temp, ub_center_temp2;
	int8_t difference, difference2;
//	uint32_t i = 0;
	
//	//Read pots
//	pot_0 = (MAL_ReadPot(0)+1)/2;
//	pot_1 = (MAL_ReadPot(1)+1)/2;
	
	//Line position
	ub_center_temp = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127
	ub_center_temp2 = (int8_t) ub_Black_Strip_Center2;	//Values from 0 to 127
	
	difference = ub_center_temp - CENTER_LINE;			//Values from -63 to 64
	difference2 = ub_center_temp2 - CENTER_LINE;			//Values from -63 to 64
	
	
	//Select algorithm
	if ((TFC_GetDIP_Switch()>>3) & 0x01) {
		centro_speed = 0.45;
		medio_speed = 0.33;
		alto_speed = 0.31;
		extremo_speed = 0.24;
	} else {
		centro_speed = 0.40;
		medio_speed = 0.30;
		alto_speed = 0.30;
		extremo_speed = 0.24;
	}
	
	
	vfnMachineState(difference, difference2);
	vfnLedState();
//	vfnAlgorithmState(difference, difference2, pot_0, pot_1);
	vfnAlgorithmState(difference, difference2);

//	/******Labview application******/
//	TERMINAL_PRINTF("\r\n");
//	TERMINAL_PRINTF("L:");
//		
//	for(i=0;i<128;i++)
//	{
//		TERMINAL_PRINTF("%X,",LineScanImage0[i]);
//	}
//	
//	for(i=0;i<128;i++)
//	{
//		TERMINAL_PRINTF("%X",LineScanImage1[i]);
//		 
//		if(i==127)
//			TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
//		else
//			TERMINAL_PRINTF(",",LineScanImage1[i]);
//	}

	
	//Turn off motors if the car doesn't detect the line
	Collision();
	
//	if (TFC_GetDIP_Switch()&0x01) {
//		vfnMachineStateGoal();
//	}
	
}

///////////////////////////////////////////////	
/////////////////*Steering*////////////////////
///////////////////////////////////////////////

void vfnDiff_1(int8_t diff, int8_t coeff){		//coeff for dummy 45
	float servo_position;
//	int8_t coeff = 45;
	
	servo_position = (float)((float)diff/(float)coeff);
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}


///////////////////////////////////////////////
////////////////////*Speed*////////////////////
///////////////////////////////////////////////

void vfnSpeedDiff(int8_t diff, float speed_ref, float coeff_turn){
	float speed_wheel_right, speed_wheel_left;
	
	if(diff > 0){		//Right turn
		speed_wheel_right = speed_ref - (speed_ref * coeff_turn);
		speed_wheel_left = speed_ref + (speed_ref * coeff_turn);
	}else{				//Left turn
		speed_wheel_right = speed_ref + (speed_ref * coeff_turn);
		speed_wheel_left = speed_ref - (speed_ref * coeff_turn);			
	}
	
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);
}

///////////////////////////////////////////////
//////////////////* Collision *////////////////
///////////////////////////////////////////////
void Collision(void)
{
	if( (FailCamLectCounter > 0) && (!collision_flag) )
	{
		SuccCamLecturesCounter = 0;
		collision_flag = 1;
	}
	
	if( (SuccCamLecturesCounter > 5) && (collision_flag) )
	{
		collision_flag = 0;
		FailCamLectCounter = 0;
	}
	
	if( (FailCamLectCounter2 > 0) && (!collision_flag2) )
	{
		SuccCamLecturesCounter2 = 0;
		collision_flag2 = 1;
	}
	
	if( (SuccCamLecturesCounter2 > 5) && (collision_flag2) )
	{
		collision_flag2 = 0;
		FailCamLectCounter2 = 0;
	}
	
	if(SuccCamLecturesCounter > 250){
		SuccCamLecturesCounter = 100;
	}
	
	if(SuccCamLecturesCounter2 > 250){
		SuccCamLecturesCounter2 = 100;
	}
}

///////////////////////////////////////////////
//////////////////* Others *///////////////////
///////////////////////////////////////////////

float convertRangeValue(float originalStart, float originalEnd, // original range
    float newStart, float newEnd, // desired range
    float value) // value to convert)
{
	float scale = (float)(newEnd - newStart) / (originalEnd - originalStart);
    return (float)(newStart + ((value - originalStart) * scale));
}

void vfnMachineStateGoal(void){
	
	switch (MachineGoal_state) {
		case LOOK_FOR_STATE:
			if ((GoalDetector == 3) || (GoalDetector2 == 3)) {
				MachineGoal_state = WAIT_TIME_STATE;
				Timer_Goal = 0;			//Reset counter
				Goal_Counter++;
			}
			
			if (Goal_Counter >= GOALS_ALLOWED) {
				MachineGoal_state = FINISH_STATE;
				Timer_Goal = 0;			//Reset counter
			}
			
			break;
		case WAIT_TIME_STATE:
			if (Timer_Goal > TIME_WAIT) {
				MachineGoal_state = LOOK_FOR_STATE;
			}
			
			break;
		case FINISH_STATE:
			TFC_BAT_LED1_ON;
			TFC_HBRIDGE_DISABLE;
			break;
		default:
			break;
	}
}

void TimerGoal(void){
	Timer_Goal++;
}

void ResetGoal(void){
	Goal_Counter = 0;
	MachineGoal_state = LOOK_FOR_STATE;
	TFC_BAT_LED1_OFF;
}

///////////////////////////////////////////////
//////////////* Machine State *////////////////
///////////////////////////////////////////////
void vfnMachineState(int8_t diff, int8_t diff2){
	uint8_t	diff_abs, diff_abs2;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	diff_abs2 = (uint8_t) getAbs((int16_t) diff2);
	
	switch (MachineState_state) {
		case CENTRO_STATE:
			if (!((SuccCamLecturesCounter2 > 5) && (diff_abs2 < CENTRO_LINEA))) {
				MachineState_state = MEDIO_STATE;
			}
			break;
		case MEDIO_STATE:
//			if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 < MEDIO_LINEA_H) && (diff_abs2 > MEDIO_LINEA_L)) {
			if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 > MEDIO_LINEA_L)) {
				MachineState_state = MEDIO_STATE;
			}else if ((SuccCamLecturesCounter2 < 5)){// || (diff_abs2 > MEDIO_LINEA_H)) {
				MachineState_state = ALTO_STATE;
			}else if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 < MEDIO_LINEA_L)) {
				MachineState_state = CENTRO_STATE;
			}
			break;
		case ALTO_STATE:
//			if ((SuccCamLecturesCounter > 5) && (diff_abs < ALTO_LINEA_H) && (diff_abs > ALTO_LINEA_L)) {
			if ((SuccCamLecturesCounter2 > 5)) {
				MachineState_state = MEDIO_STATE;
			}else if ((SuccCamLecturesCounter < 5)){// || (diff_abs > ALTO_LINEA_H)) {
				MachineState_state = EXTREMO_STATE;
//			}else if ((SuccCamLecturesCounter > 5) && (diff_abs < ALTO_LINEA_L)) {
			}else if ((SuccCamLecturesCounter > 5)) {
				MachineState_state = ALTO_STATE;
			}		
			break;
		case EXTREMO_STATE:
//			if ((SuccCamLecturesCounter > 5) && (diff_abs < EXTREMO_LINEA)) {
			if ((SuccCamLecturesCounter > 5)) {
				MachineState_state = ALTO_STATE;
			}	
			break;
		default:
			break;
	}
}

void vfnLedState(void)
{
	switch (MachineState_state) {
		case CENTRO_STATE:
			/* green on */
			red_off();
			green_on();
			blue_off();	
			break;
		case MEDIO_STATE:
			/* blue */
			red_off();
			green_off();
			blue_on();
			break;
		case ALTO_STATE:
			/* green + blue */
			red_off();
			green_on();
			blue_on();
			break;
		case EXTREMO_STATE:
			/* red on */
			red_on();
			green_off();
			blue_off();
			break;
		default:
			break;
	}
}

//void vfnAlgorithmState(int8_t diff, int8_t diff2, float speed_low, float speed_high)
void vfnAlgorithmState(int8_t diff, int8_t diff2)
{
	int8_t average_steering;
//	float average_speed;
	
	average_steering = (diff + diff2)/2;
//	average_speed = (speed_low + speed_high)/2;
	
	switch (MachineState_state) {
		case CENTRO_STATE:
			
			vfnDiff_1(average_steering, CENTRO_STEERING_COEFF);					//Steering
			vfnSpeedDiff(average_steering, centro_speed, CENTRO_SPEED_COEFF);		//Speed
			
			break;
		case MEDIO_STATE:
			
			vfnDiff_1(average_steering, MEDIO_STEERING_COEFF);				//Steering
			vfnSpeedDiff(average_steering, medio_speed, MEDIO_SPEED_COEFF);		//Speed
			
			break;
		case ALTO_STATE:
			
			vfnDiff_1(diff, ALTO_STEERING_COEFF);					//Steering
			vfnSpeedDiff(diff, alto_speed, ALTO_SPEED_COEFF);		//Speed
			
			break;
		case EXTREMO_STATE:
			
			vfnDiff_1(diff, EXTREMO_STEERING_COEFF);			//Steering
			vfnSpeedDiff(diff, extremo_speed, EXTREMO_SPEED_COEFF);		//Speed
			
			break;
		default:
			break;
	}
}
