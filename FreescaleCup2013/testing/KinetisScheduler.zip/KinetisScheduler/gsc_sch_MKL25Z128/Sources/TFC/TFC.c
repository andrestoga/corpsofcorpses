#include "TFC\TFC.h"


void TFC_Init()
{
	//TFC_InitClock();
	InitClock();
	//TFC_InitSysTick();
	InitSysTick();
	TFC_InitGPIO();
	//TFC_InitServos();
	//TFC_InitMotorPWM();
    //TFC_InitADCs();
	InitADC0();
    //TFC_InitLineScanCamera();
    vfnInitCamera();
    vfnStartCapturing();
    TFC_InitTerminal();
	TFC_InitUARTs();
	vfnInitStates();
	//TFC_HBRIDGE_DISABLE;
	//TFC_SetMotorPWM(0,0);
}

void TFC_Task()
{
	#if defined(TERMINAL_USE_SDA_SERIAL)
		TFC_UART_Process();
	#endif
	 
    TFC_ProcessTerminal();
}
