/*============================================================================*/
/*                        Tortoise Team			                              */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:         %APP_Machine_State.c%
* Instance:         RPL_1
* %version:         1.0 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Sunday Sep  30 14:38:03 2012 %
*=============================================================================*/
/* DESCRIPTION : C source file for the machine state.                         */
/*============================================================================*/
/* FUNCTION COMMENT : This file contains the function and variable definitions*/
/*					  of the machine state                                    */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 30/09/2012  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/

/** \brief Pointer to function for the machine state. */
void (*ptrFctnMachineState[NUM_STATES]) (void);

/** \brief State of the machine state. */
enum STATE en_State = FIRST_STATE;

/** \brief Variable used to toggle the state of the back wheels. */
static uint8_t toggle = 1;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */

void vfnFirstState(void);
void vfnSecondState(void);
void vfnThirdState(void);
void vfnFourState(void);

/* Exported functions prototypes */
/* ----------------------------- */

void vfnInitStates(void);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */
/**************************************************************
 *  Name                 : vfnFirstState
 *  Description          : The first state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The first state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnFirstState(void)
{
	//vfnCalibrate_FrontWheels();
	
	//Turn on led 1
	TFC_BAT_LED0_ON;

	if(TFC_PUSH_BUTTON_0_PRESSED)
	{
		en_State = SECOND_STATE;
		
		TFC_BAT_LED0_OFF;
		TFC_BAT_LED1_ON;
	}
}

/**************************************************************
 *  Name                 : vfnSecondState
 *  Description          :	The second state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The second state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnSecondState(void)
{
	if(TFC_PUSH_BUTTON_0_PRESSED)
	{
		en_State = THIRD_STATE;
	
		TFC_BAT_LED1_OFF;
		TFC_BAT_LED2_ON;
	}
	
	vfn_calibrateLine();
}

/**************************************************************
 *  Name                 : vfnThirdState
 *  Description          : The third state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The third state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnThirdState(void)
{
	if(TFC_PUSH_BUTTON_0_PRESSED)
	{
		en_State = FOUR_STATE;
		
		//vfnStart_DcMotor(2);
		
		TFC_BAT_LED2_OFF;
		TFC_BAT_LED3_ON;
	}
	
}

/**************************************************************
 *  Name                 : vfnFourState
 *  Description          : The four state of the machine state.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief The four state of the machine state.
/////////////////////////////////////////////////////////////////////////
void vfnFourState(void)
{
	float NewPwm;
		if(TFC_PUSH_BUTTON_1_PRESSED)
	{	
		if(toggle)
		{
			toggle = 0;
			//vfnStop_DcMotor(2);
			TFC_HBRIDGE_DISABLE;
		}
		else
		{
			toggle = 1;
			//vfnStart_DcMotor(2);
			TFC_HBRIDGE_ENABLE;
		}
	}
	
	//Toggle led 4
	TFC_BAT_LED3_TOGGLE;
	
	NewPwm = MAL_ReadPot(0);
	HAL_SetMotorPWM(NewPwm,NewPwm);
	
	vfn_processPixels();
	
	vfnFirstVersion();
	
	//Testing
	//vfnSetPos_FrontWheels(SM_KNOB(GET_KNOB_VALUE));
}

/* Exported functions */
/* ------------------ */

/**************************************************************
 *  Name                 : vfnInitStates
 *  Description          : Initialize the pointer to function states.
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :	void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Initialize the pointer to function states.
/////////////////////////////////////////////////////////////////////////
void vfnInitStates(void)
{
	ptrFctnMachineState[0] = &vfnFirstState;
	ptrFctnMachineState[1] = &vfnSecondState;
	ptrFctnMachineState[2] = &vfnThirdState;
	ptrFctnMachineState[3] = &vfnFourState;
}
