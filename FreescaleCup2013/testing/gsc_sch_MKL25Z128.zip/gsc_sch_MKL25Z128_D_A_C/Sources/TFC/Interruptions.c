/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* C Source:         %Interruptions.c%
* Instance:         RPL_1
* %version:         1.0 %
* %created_by:      Andres Torres Garcia %
* %date_created:    Fri Sep  27 00:21:03 2013 %
*=============================================================================*/
/* DESCRIPTION : All the function interruption definitions will be located here*/
/*============================================================================*/
/* FUNCTION COMMENT : This file describes the C source template according to  */
/* the new software platform                                                  */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION |   DATE      |                               |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*  1.0      | 27/09/2013  |                               | Andres Torres    */
/* Integration under Continuus CM                                             */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/ 

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */

/* Exported functions prototypes */
/* ----------------------------- */
void PIT_IRQHandler(void);
void ADC0_IRQHandler(void);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */
/**************************************************************
 *  Name                 : 
 *  Description          :
 *  Parameters           :  [Input, Output, Input / output]
 *  Return               :
 *  Critical/explanation :    No
 **************************************************************/

/* Exported functions */
/* ------------------ */
/******************************************************************************
Function 1. Name	PIT_IRQHandler   

Parameters		No parameters.
Returns			No return value.
Notes         	None
******************************************************************************/
void PIT_IRQHandler(void)
{
	PIT_TFLG0 = PIT_TFLG_TIF_MASK; //Turn off the Pit 0 Irq flag 
	
	//Macro in the Line Scan Camera module
	TAOS_SI_HIGH;
	//Prime the ADC pump and start capturing POT 0
	CurrentADC_State = ADC_STATE_CAPTURE_POT_0;
	
	ADC0_CFG2  &= ~ADC_CFG2_MUXSEL_MASK; //Select the A side of the mux
	
	ADC0_SC1A  =  TFC_POT_0_ADC_CHANNEL | ADC_SC1_AIEN_MASK;  //Start the State machine at POT0
}

/******************************************************************************
Function 1. Name	ADC0_IRQHandler   

Parameters		No parameters.
Returns			No return value.
Notes         	None
******************************************************************************/
void ADC0_IRQHandler(void)
{
	vfnCapturePixels();
}//End of function
