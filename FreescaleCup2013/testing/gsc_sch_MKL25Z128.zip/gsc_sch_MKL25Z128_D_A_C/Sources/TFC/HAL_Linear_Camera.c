/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            HAL_Linear_Camera.c
* version:         1.0
* %created_by:      Andres Torres Garcia %
* %date_created:    Tuesday August 04 00:19:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for uC Abstraction layer for ADC module          */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for uC Abstraction Layer for ADC*/
/*              module                                                        */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 03/09/2013 |                   | Andres Torres     */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

/* Functions macros, constants, types and datas         */
/* ---------------------------------------------------- */
/* Functions macros */

/*==================================================*/ 
/* Definition of constants                          */
/*==================================================*/ 


/*======================================================*/ 
/* Definition of RAM variables                          */
/*======================================================*/

volatile uint16_t PotADC_Value[2];
volatile uint16_t BatSenseADC_Value;
volatile uint8_t  CurrentADC_State;	

volatile uint8_t CurrentLineScanPixel = 0;
volatile uint8_t CurrentLineScanChannel = 0;

volatile uint16_t  *LineScanImage0WorkingBuffer;
volatile uint16_t  *LineScanImage1WorkingBuffer;
volatile uint16_t  *LineScanImage0;
volatile uint16_t  *LineScanImage1;
volatile uint16_t  LineScanImage0Buffer[2][128];
volatile uint16_t  LineScanImage1Buffer[2][128];
volatile uint8_t  LineScanWorkingBuffer;

volatile uint8_t LineScanImageReady = 0;

/*======================================================*/ 
/* close variable declaration sections                  */
/*======================================================*/ 

/* Private defines */

/* Private functions prototypes */
/* ---------------------------- */


/* Exported functions prototypes */
/* ----------------------------- */

void vfnInitCamera(void);
void vfnCapturePixels(void);
void vfnStopCamera(void);
void vfnStartCamera(void);
void vfnStartCapturing(void);
void vfnStopCapturing(void);

void TFC_SetLineScanExposureTime(uint32_t  TimeIn_uS);
void vfnInit_PIT0(void);
float TFC_ReadPot(uint8_t Channel);
float TFC_ReadBatteryVoltage(void);

/* Inline functions */
/* ---------------- */

/* Private functions */
/* ----------------- */

/* Exported functions */
/* ------------------ */

/******************************************************************************
Function 1. Name	TFC_ReadPot   

Parameters		
Returns			None
Notes         	Pot Reading is Scaled to return a value of -1.0 to 1.0	
******************************************************************************/
float TFC_ReadPot(uint8_t Channel)
{
    if(Channel == 0)
        return ((float)PotADC_Value[0]/-((float)ADC_MAX_CODE/2.0))+1.0;
    else
        return ((float)PotADC_Value[1]/-((float)ADC_MAX_CODE/2.0))+1.0;
}

/******************************************************************************
Function 1. Name	TFC_ReadBatteryVoltage   

Parameters		
Returns			None
Notes         	None	
******************************************************************************/
float TFC_ReadBatteryVoltage()
{
    return (((float)BatSenseADC_Value/(float)(ADC_MAX_CODE)) * 3.0);// * ((47000.0+10000.0)/10000.0);
}

/**************************************************************
 *  Name                 : TFC_SetLineScanExposureTime
 *  Description          : 
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
void TFC_SetLineScanExposureTime(uint32_t  TimeIn_uS)
{
	float t;
	
	//Figure out how many Pit ticks we need for the exposure time
	t = (TimeIn_uS /1000000.0) * (float)(PERIPHERAL_BUS_CLOCK);
	
	//Function for the PIT module
	PIT_LDVAL0 = (uint32_t)t;
	
}

/**************************************************************
 *  Name                 : vfnInit_PIT0
 *  Description          :      Initialize the PIT 0
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Initialize the PIT 0
/////////////////////////////////////////////////////////////////////////
void vfnInit_PIT0(void)
{
	    //The pump will be primed with the PIT interrupt.  upon timeout/interrupt it will set the SI signal high
		//for the camera and then start the conversions for the pots.
		
		//Enable clock to the PIT
		SIM_SCGC6 |= SIM_SCGC6_PIT_MASK;
		
		//We will use PIT0
		TFC_SetLineScanExposureTime(TFC_DEFAULT_LINESCAN_EXPOSURE_TIME_uS);
		
		//enable PIT0 and its interrupt
		PIT_TCTRL0 = PIT_TCTRL_TEN_MASK | PIT_TCTRL_TIE_MASK;
		
		PIT_MCR |= PIT_MCR_FRZ_MASK; // stop the pit when in debug mode
		
		//Enable the PIT module
		//PIT_MCR &= ~PIT_MCR_MDIS_MASK;
}

/**************************************************************
 *  Name                 : vfnInitCamera
 *  Description          :      Initialize the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Initialize the Linear Camera
/////////////////////////////////////////////////////////////////////////
void vfnInitCamera(void)
{
	//All Adc processing of the Pots and linescan will be done in the ADC0 IRQ!
	//A state machine will scan through the channels.
	//This is done to automate the linescan capture on Channel 0 to ensure that timing is very even
	CurrentADC_State =	ADC_STATE_INIT;	
	
	vfnInit_PIT0();
	
	enable_irq(INT_PIT-16);
	enable_irq(INT_ADC0-16);
	
	SIM_SCGC5 |=     SIM_SCGC5_PORTE_MASK | SIM_SCGC5_PORTD_MASK; //Make sure the clock is enabled for PORTE;
	
	PORTE_PCR1 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;   //Enable GPIO on on the pin for the CLOCK Signal
	PORTD_PCR7 = PORT_PCR_MUX(1) | PORT_PCR_DSE_MASK;   //Enable GPIO on on the pin for SI signal
	
	PORTD_PCR5 = PORT_PCR_MUX(0); //Make sure AO signal goes to an analog input
	PORTD_PCR6 = PORT_PCR_MUX(0); //Make sure AO signal goes to an analog input
		
	//Make sure the Clock and SI pins are outputs
    GPIOD_PDDR |= (1<<7);
    GPIOE_PDDR |= (1<<1);
    
	TAOS_CLK_LOW;
	TAOS_SI_LOW;

	LineScanWorkingBuffer = 0;
	
	LineScanImage0WorkingBuffer = &LineScanImage0Buffer[0][0];
	LineScanImage1WorkingBuffer = &LineScanImage1Buffer[0][0];
	
	LineScanImage0 = &LineScanImage0Buffer[1][0];
	LineScanImage1 = &LineScanImage1Buffer[1][0];
}

/**************************************************************
 *  Name                 : vfnStopCamera
 *  Description          :      Stop the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Stop the Linear Camera
/////////////////////////////////////////////////////////////////////////
void vfnStopCamera(void)
{
        
}

/**************************************************************
 *  Name                 : vfnStartCamera
 *  Description          :      Start the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Start the Linear Camera
/////////////////////////////////////////////////////////////////////////
void vfnStartCamera(void)
{
        
}

/**************************************************************
 *  Name                 : vfnStartCapturing
 *  Description          :      Start capturing the pixels of the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Start capturing pixels from the Linear Camera.
/////////////////////////////////////////////////////////////////////////
void vfnStartCapturing(void)
{
	PIT_MCR &= ~PIT_MCR_MDIS_MASK;
}

/**************************************************************
 *  Name                 : vfnStopCapturing
 *  Description          :      Stop capturing the pixels of the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Stop capturing pixels from the Linear Camera.
/////////////////////////////////////////////////////////////////////////
void vfnStopCapturing(void)
{
        
}

/**************************************************************
 *  Name                 : vfnCapturePixels
 *  Description          :      Capture the pixels of the linear camera.
 *  Parameters           :  [Input; Output; Input / output]
 *  Return               :      void
 *  Critical/explanation :    No
 **************************************************************/
///////////////////////////////////////////////////////////////////////
/// \brief Capture 128 pixels of the Linear Camera.
/////////////////////////////////////////////////////////////////////////
void vfnCapturePixels(void)
{
	uint8_t Junk;
		
		switch(CurrentADC_State)
		{
			case ADC_STATE_CAPTURE_POT_0:
			
					PotADC_Value[0] = ADC0_RA;
					ADC0_CFG2  &= ~ADC_CFG2_MUXSEL_MASK; //Select the A side of the mux
					ADC0_SC1A  =  TFC_POT_1_ADC_CHANNEL | ADC_SC1_AIEN_MASK;
					CurrentADC_State = ADC_STATE_CAPTURE_POT_1;
					
				break;
			
			case ADC_STATE_CAPTURE_POT_1:
			
					PotADC_Value[1] = ADC0_RA;
					ADC0_CFG2  |= ADC_CFG2_MUXSEL_MASK; //Select the B side of the mux
					ADC0_SC1A  =  TFC_BAT_SENSE_CHANNEL| ADC_SC1_AIEN_MASK;
					CurrentADC_State = ADC_STATE_CAPTURE_BATTERY_LEVEL;
					
				break;
			
			case ADC_STATE_CAPTURE_BATTERY_LEVEL:
				
					BatSenseADC_Value = ADC0_RA;
					
					//Now we will start the sequence for the Linescan camera
					TAOS_CLK_HIGH;
					
					for(Junk = 0;Junk<50;Junk++)
					{
					}
					
					TAOS_SI_LOW;
					
					CurrentLineScanPixel = 0;
					CurrentLineScanChannel = 0;
					CurrentADC_State = ADC_STATE_CAPTURE_LINE_SCAN;
					ADC0_CFG2  |= ADC_CFG2_MUXSEL_MASK; //Select the B side of the mux
					ADC0_SC1A  =  TFC_LINESCAN0_ADC_CHANNEL | ADC_SC1_AIEN_MASK;
					
					break;
			
			case ADC_STATE_CAPTURE_LINE_SCAN:
						
						if(CurrentLineScanPixel<128)
						{
							if(CurrentLineScanChannel == 0)
							{
								LineScanImage0WorkingBuffer[CurrentLineScanPixel] = ADC0_RA;
								ADC0_SC1A  =  TFC_LINESCAN1_ADC_CHANNEL | ADC_SC1_AIEN_MASK;
								CurrentLineScanChannel = 1;
								
							}//End of if
							else
							{
								LineScanImage1WorkingBuffer[CurrentLineScanPixel] = ADC0_RA;
								ADC0_SC1A  =  TFC_LINESCAN0_ADC_CHANNEL | ADC_SC1_AIEN_MASK;
								CurrentLineScanChannel = 0;
								CurrentLineScanPixel++;
								
								TAOS_CLK_LOW;
								
								for(Junk = 0;Junk<50;Junk++)
								{
								}

								TAOS_CLK_HIGH;
								
							}//End of else
							
						}//End of if
						else
						{
							// done with the capture sequence.  we can wait for the PIT0 IRQ to restart
							TAOS_CLK_HIGH;
												
							for(Junk = 0;Junk<50;Junk++)
							{
							}//End of for
							
							TAOS_CLK_LOW;
							
							CurrentADC_State = ADC_STATE_INIT;	 
							
							//swap the buffer
							if(LineScanWorkingBuffer == 0)
							{
								LineScanWorkingBuffer = 1;
								
								LineScanImage0WorkingBuffer = &LineScanImage0Buffer[1][0];
								LineScanImage1WorkingBuffer = &LineScanImage1Buffer[1][0];
								
								LineScanImage0 = &LineScanImage0Buffer[0][0];
								LineScanImage1 = &LineScanImage1Buffer[0][0];
							}//End of if
							else
							{
								LineScanWorkingBuffer = 0;
								LineScanImage0WorkingBuffer = &LineScanImage0Buffer[0][0];
								LineScanImage1WorkingBuffer = &LineScanImage1Buffer[0][0];
								
								LineScanImage0 = &LineScanImage0Buffer[1][0];
								LineScanImage1 = &LineScanImage1Buffer[1][0];
							}//End of else
							
							LineScanImageReady = TRUE;
						}//End of else
						
						break;
						
						default:
								Junk =  ADC0_RA;
						break;
		}//End of switch
}
