/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for algorithms by Oscar									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the algorithms			  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"

#define CENTER_LINE		63
#define WHEEL_RIGHT		0
#define WHEEL_LEFT		1

/*Snake variables*/
#define STRAIGHT_STATE	0
#define CURVE_STATE		1
#define SNAKE_COEFF		65
#define STRAIGHT_COEFF	40

/* Machine State */
#define CENTRO_STATE	1
#define MEDIO_STATE		2
#define ALTO_STATE		3
#define EXTREMO_STATE	4

#define CENTRO_LINEA	25
#define MEDIO_LINEA_L	25
#define MEDIO_LINEA_H	50
#define ALTO_LINEA_L	25
#define ALTO_LINEA_H	55
#define EXTREMO_LINEA	40

#define CENTRO_STEERING_COEFF	65
#define MEDIO_STEERING_COEFF	50
#define ALTO_STEERING_COEFF		40
#define EXTREMO_STEERING_COEFF	38

#define CENTRO_SPEED_COEFF	0
#define MEDIO_SPEED_COEFF	0.05
#define ALTO_SPEED_COEFF	0.13
#define EXTREMO_SPEED_COEFF	0.18

/* Machine Goal */
#define LOOK_FOR_STATE		0
#define WAIT_TIME_STATE		1
#define FINISH_STATE		2
#define TIME_WAIT			200		//x*(10ms)
#define GOALS_ALLOWED		2		

uint8_t collision_flag = 0;
uint8_t collision_flag2 = 0;

/*PID variables*/
float servo_position_PID = 0;
float lastError = 0;
float integral = 0;

/*Snake variables*/
uint8_t snakeSate = STRAIGHT_STATE;		//Begins on straight line

/* Machine State Variables*/
uint8_t MachineState_state = CENTRO_STATE;

/* Machine State Variables*/
uint8_t MachineGoal_state = LOOK_FOR_STATE;
uint8_t Goal_Counter = 0;				//Quantity of goals
uint8_t Timer_Goal = 0;					//Time in wait state

void vfnAlgorithmsORA(void){
	float pot_0, pot_1;
	int8_t ub_center_temp, ub_center_temp2;
	int8_t difference, difference2;
//	uint32_t i = 0;
	
	//Read pots
	pot_0 = (MAL_ReadPot(0)+1)/2;
	pot_1 = (MAL_ReadPot(1)+1)/2;
	
	//Line position
	ub_center_temp = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127
	ub_center_temp2 = (int8_t) ub_Black_Strip_Center2;	//Values from 0 to 127
	
	difference = ub_center_temp - CENTER_LINE;			//Values from -63 to 64
	difference2 = ub_center_temp2 - CENTER_LINE;			//Values from -63 to 64
	
//	if(TFC_PUSH_BUTTON_0_PRESSED)
//	{	
//		vfnTwoSpeeds(difference, pot_0, pot_0);
//	}else{
//		vfnTwoSpeeds(difference, pot_1, pot_1);
//	}
	
	vfnMachineState(difference, difference2);
	vfnLedState();
	vfnAlgorithmState(difference, difference2, pot_0, pot_1);
	
//	//Select algorithm
//	switch(TFC_GetDIP_Switch()&0x03){
//		case 0:
//			vfnPID_Steering(difference);
////			vfnDiff_1(difference);
////			vfnHybridSnake_Steering(difference, difference2);
//			vfnSpeedsHard(difference, pot_0, pot_1, 0.13);	//0.12 is the theory
//			
////			vfnSpeedDiff_1(difference, pot_0);
////			vfnSpeedsSoft(difference, pot_0, pot_1);
////			vfnConstant(pot_0);
////			vfnTwoSpeeds(difference, pot_0, pot_1);
//			
////			Tests
////			HAL_SetServo(MAL_ReadPot(0));
////			vfnConstant2(pot_0, pot_1);
////			HAL_SetMotorPWM(pot_0, pot_0);
//			break;
//		case 1:
////			vfnDiff_1(difference);
//			vfnDiff_Hybrid(difference);
////			vfnSpeedsHard(difference, pot_0, pot_1, 0.15);
//			vfnSpeedDiff_1(difference, pot_0);
////			vfnSpeedsHard(difference, pot_0, pot_1, 0.20);
////			vfnSpeedsSoft(difference, pot_0, pot_1);
////			vfnDiff_2(difference);
////			vfnTwoSpeeds(difference, pot_0, pot_1);
////			vfnConstant(pot_0);
//			break;
//		case 2:
////			vfnDiff_1(difference);
//			vfnDiff_Hybrid2(difference);
////			vfnSpeedsHard(difference, pot_0, pot_1, 0.15);
//			vfnSpeedDiff_1(difference, pot_0);
////			vfnSpeedsSoft(difference, pot_0, pot_1);
////			vfnDiff_3(difference);
////			vfnTwoSpeeds(difference, pot_0, pot_1);
////			vfnConstant(pot_0);
//			break;
//		case 3:
////			vfnDiff_1(difference);
////			vfnSpeedsHard(difference, pot_0, pot_1, 0.20);
//			
////			vfnSpeedsSoft(difference, pot_0, pot_1);
////			vfnPid(difference,pot_1);
////			vfnConstant(pot_0);
//			break;
//	}
//	
//	//It sends information using serial port
//	switch((TFC_GetDIP_Switch()>>2)&0x03){
//		case 0:
//			//Nothing
//			break;
//		case 1:
//			//After binarization
//			TERMINAL_PRINTF("%d ", pat_info.value);
//			TERMINAL_PRINTF("%d ", pat_info.valid);
//			TERMINAL_PRINTF("%d ", ub_Black_Strip_Center);
//			TERMINAL_PRINTF("%d ", ub_Black_Strip_Width);
//			TERMINAL_PRINTF("\r\n");
//		 
//			for(i = 0;i < 128;i++)
//			{
//				TERMINAL_PRINTF("%d",ub_Bin_Pixels[i]);
////				TERMINAL_PRINTF("%d",LineScanImage0[i]);
//			} 
//			TERMINAL_PRINTF("\r\n");
//			break;
//		case 2:
//			//Labview application
//			TERMINAL_PRINTF("\r\n");
//			TERMINAL_PRINTF("L:");
//				
//			for(i=0;i<128;i++)
//			{
//				TERMINAL_PRINTF("%X,",LineScanImage0[i]);
//			}
//			
//			for(i=0;i<128;i++)
//			{
//				TERMINAL_PRINTF("%X",LineScanImage1[i]);
//				 
//				if(i==127)
//					TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
//				else
//					TERMINAL_PRINTF(",",LineScanImage1[i]);
//			}
//			break;
//		case 3:
//			//Speed sensor
//			TERMINAL_PRINTF("%d", (uint8_t)(HAL_GetSpeed(WHEEL_RIGHT)*100));
//			//Steering direction
////			TERMINAL_PRINTF("%d", (uint8_t)(MAL_ReadPot(0)*1000));
//			TERMINAL_PRINTF("\r\n");
//			break;
//	}
	
	//Turn off motors if the car doesn't detect the line
	Collision();
	vfnMachineStateGoal();
}

///////////////////////////////////////////////	
/////////////////*Steering*////////////////////
///////////////////////////////////////////////

void vfnDiff_1(int8_t diff, int8_t coeff){		//coeff for dummy 45
	float servo_position;
//	int8_t coeff = 45;
	
	servo_position = (float)((float)diff/(float)coeff);
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_2(int8_t diff){
	float servo_position;
	int8_t coeff = 35;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position;
	
	if(diff < 0){
		servo_position = servo_position * (-1);
	}
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_3(int8_t diff){
	float servo_position;
	int8_t coeff = 40;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position*servo_position;
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_Hybrid(int8_t diff){
	float servo_position;
	int8_t coeff_1 = 45;
	int8_t coeff_2 = 35;
	
	if((diff > -27) && (diff < 27)){	//Quadratic function
		servo_position = (float)((float)diff/(float)coeff_2);
		servo_position = servo_position*servo_position;
		
		if(diff < 0){
			servo_position = servo_position * (-1);
		}
	}else{
		servo_position = (float)((float)diff/(float)coeff_1);	//Linear
	}
		
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_Hybrid2(int8_t diff){
	float servo_position;
	int8_t coeff_1 = 45;
	int8_t coeff_2 = 33;
	
	if((diff > -27) && (diff < 27)){	//Cube function
		servo_position = (float)((float)diff/(float)coeff_2);
		servo_position = servo_position*servo_position*servo_position;
	}else{
		servo_position = (float)((float)diff/(float)coeff_1);	//Linear
	}
		
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnPID_Steering(int8_t diff){
	float kp = 0.06;
//	float ki = 0.00001;
	float kd = 0.8;
	float RefSteering = 0;
	float error = 0;
	float low_limit_steering = -1;
	float max_limit_steering = 1;
	float current_steering;
	float derivative;
	
	if((diff > -35) && (diff < 35)){
		kp = 0.04;
	}else{
		kp = 0.06;
	}
	
	current_steering = (float)((float)diff/(float)64);		//Get the current steering from -1 to 1
	
	error = RefSteering + current_steering;	//Calculate the error
	
//	integral = integral + error;		//Calculate the integral
	
	derivative = error - lastError;		//Calculate the derivative
	
//	servo_position_PID += (kp*error) + (ki*integral) + (kd*derivative);			//PID controller
//	servo_position_PID += (kp*error) + (ki*integral);			//PI controller
	servo_position_PID += (kp*error) + (kd*derivative);			//PD controller
//	servo_position_PID += (kp*error);			//P controller
	
	//Limit the steering position
	if(servo_position_PID < low_limit_steering){
		servo_position_PID = low_limit_steering;
	}else if(servo_position_PID > max_limit_steering){
		servo_position_PID = max_limit_steering;
	}
	
	HAL_SetServo(servo_position_PID);
	
	//Save the current error for the next iteration
	lastError = error;
}

void vfnSnake_Steering(int8_t diff, int8_t diff2){
	int8_t average;
	average = (diff + diff2)/2;
	vfnDiff_1(average, SNAKE_COEFF);
}

void vfnHybridSnake_Steering(int8_t diff, int8_t diff2){
	
//	switch (snakeSate) {
//		case STRAIGHT_STATE:
//			vfnSnake_Steering(diff, diff2);
//			if( ((diff2 < -23) && (diff2 > 23)) || (FailCamLectCounter2) ){
//				snakeSate = CURVE_STATE;
//			}
//			/* green on */
//			red_off();
//			green_on();
//			blue_off();
//			break;
//		case CURVE_STATE:
//			vfnDiff_1(diff, STRAIGHT_COEFF);
//			if((diff2 > -13) && (diff2 < 13) && (SuccCamLecturesCounter2 > 5)){
//				snakeSate = STRAIGHT_STATE;
//			}
//			/* red on */
//			red_on();
//			green_off();
//			blue_off();
//			break;
//		default:
//			break;
//	}
}

void HAL_ResetPID_Values_Steering(void){
	lastError = 0;
//	integral = 0;
	servo_position_PID = 0;
}

///////////////////////////////////////////////
////////////////////*Speed*////////////////////
///////////////////////////////////////////////

void vfnConstant(float speed_const){
	HAL_SetSpeed(speed_const,speed_const);				//With SPEED CONTRO
}

void vfnConstant2(float speed_right, float speed_left){
	HAL_SetSpeed(speed_right, speed_left);				//With SPEED CONTROL
}

void vfnTwoSpeeds(int8_t diff, float low_speed, float high_speed){
	float speed_wheel;
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 5;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel = high_speed;
	}else{
		speed_wheel = low_speed;
	}
	
	HAL_SetSpeed(speed_wheel,speed_wheel);				//With SPEED CONTROL
}

void vfnSpeedsHard(int8_t diff, float low_speed, float high_speed, float coeff){
	float speed_wheel_right, speed_wheel_left;
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 25;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel_right = high_speed;
		speed_wheel_left = high_speed;
	}else{
		if(diff > 0){		//Right turn
			speed_wheel_right = low_speed - (low_speed*coeff);
			speed_wheel_left =  low_speed + (low_speed*coeff);
		}else{				//Left turn
			speed_wheel_right = low_speed + (low_speed*coeff);
			speed_wheel_left =  low_speed - (low_speed*coeff);
		}
	}
	
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);				//With SPEED CONTROL
}

void vfnSpeedsSoft(int8_t diff, float low_speed, float high_speed){
	float speed_wheel_right, speed_wheel_left;
	float coeff = 1/(3*100);
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 5;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel_right = high_speed;
		speed_wheel_left = high_speed;
	}else{
		if(diff > 0){		//Right turn
			speed_wheel_right = low_speed - (low_speed*(((float)diff_abs)*coeff));
			speed_wheel_left =  low_speed + (low_speed*(((float)diff_abs)*coeff));
		}else{				//Left turn
			speed_wheel_right = low_speed + (low_speed*(((float)diff_abs)*coeff));
			speed_wheel_left =  low_speed - (low_speed*(((float)diff_abs)*coeff));
		}
	}
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);				//With SPEED CONTROL
}


void vfnSpeedDiff_1(int8_t diff, float max_speed){
	float speed_wheel_right, speed_wheel_left;
	float speed_wheel;
	float coeff_turn = 0.12;
	int8_t coeff = 35;
	uint8_t	diff_abs;
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	speed_wheel = 1.0 - ((float)((float)diff_abs/(float)coeff));
	speed_wheel = max_speed * speed_wheel;
	
	if(speed_wheel > 1.0){
		speed_wheel = 1.0;
	}else if(speed_wheel < 0.3){
		speed_wheel = 0.3;
	}
	
	if(diff_abs > 22){
		if(diff > 0){		//Right turn
			speed_wheel_right = speed_wheel - (speed_wheel * coeff_turn);
			speed_wheel_left = speed_wheel + (speed_wheel * coeff_turn);
		}else{				//Left turn
			speed_wheel_right = speed_wheel + (speed_wheel * coeff_turn);
			speed_wheel_left = speed_wheel - (speed_wheel * coeff_turn);			
		}
	}else{
		speed_wheel_right = speed_wheel;
		speed_wheel_left = speed_wheel;
	}
	
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);
}

void vfnSpeedDiff(int8_t diff, float speed_ref, float coeff_turn){
	float speed_wheel_right, speed_wheel_left;
	
	if(diff > 0){		//Right turn
		speed_wheel_right = speed_ref - (speed_ref * coeff_turn);
		speed_wheel_left = speed_ref + (speed_ref * coeff_turn);
	}else{				//Left turn
		speed_wheel_right = speed_ref + (speed_ref * coeff_turn);
		speed_wheel_left = speed_ref - (speed_ref * coeff_turn);			
	}
	
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);
}

///////////////////////////////////////////////
//////////////////* Collision *////////////////
///////////////////////////////////////////////
void Collision(void)
{
	if( (FailCamLectCounter > 0) && (!collision_flag) )
	{
		SuccCamLecturesCounter = 0;
		collision_flag = 1;
//		TFC_HBRIDGE_DISABLE;
	}
	
	if( (SuccCamLecturesCounter > 5) && (collision_flag) )
	{
		collision_flag = 0;
		FailCamLectCounter = 0;
//		HAL_ResetPID_Values();
//		TFC_HBRIDGE_ENABLE;
	}
	
	if( (FailCamLectCounter2 > 0) && (!collision_flag2) )
	{
		SuccCamLecturesCounter2 = 0;
		collision_flag2 = 1;
	}
	
	if( (SuccCamLecturesCounter2 > 5) && (collision_flag2) )
	{
		collision_flag2 = 0;
		FailCamLectCounter2 = 0;
	}
	
	if(SuccCamLecturesCounter > 250){
		SuccCamLecturesCounter = 100;
	}
	
	if(SuccCamLecturesCounter2 > 250){
		SuccCamLecturesCounter2 = 100;
	}
}

///////////////////////////////////////////////
//////////////////* Others *///////////////////
///////////////////////////////////////////////

float convertRangeValue(float originalStart, float originalEnd, // original range
    float newStart, float newEnd, // desired range
    float value) // value to convert)
{
	float scale = (float)(newEnd - newStart) / (originalEnd - originalStart);
    return (float)(newStart + ((value - originalStart) * scale));
}

void vfnMachineStateGoal(void){
	
	switch (MachineGoal_state) {
		case LOOK_FOR_STATE:
			if ((GoalDetector == 3) || (GoalDetector2 == 3)) {
				MachineGoal_state = WAIT_TIME_STATE;
				Timer_Goal = 0;			//Reset counter
				Goal_Counter++;
			}
			
			if (Goal_Counter >= GOALS_ALLOWED) {
				MachineGoal_state = FINISH_STATE;
				Timer_Goal = 0;			//Reset counter
			}
			
			break;
		case WAIT_TIME_STATE:
			if (Timer_Goal > TIME_WAIT) {
				MachineGoal_state = LOOK_FOR_STATE;
			}
			
			break;
		case FINISH_STATE:
			TFC_BAT_LED1_ON;
			TFC_HBRIDGE_DISABLE;
			break;
		default:
			break;
	}
}

void TimerGoal(void){
	Timer_Goal++;
}

void ResetGoal(void){
	Goal_Counter = 0;
	MachineGoal_state = LOOK_FOR_STATE;
	TFC_BAT_LED1_OFF;
}

///////////////////////////////////////////////
//////////////* Machine State *////////////////
///////////////////////////////////////////////
void vfnMachineState(int8_t diff, int8_t diff2){
	uint8_t	diff_abs, diff_abs2;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	diff_abs2 = (uint8_t) getAbs((int16_t) diff2);
	
	switch (MachineState_state) {
		case CENTRO_STATE:
			if (!((SuccCamLecturesCounter2 > 5) && (diff_abs2 < CENTRO_LINEA))) {
				MachineState_state = MEDIO_STATE;
			}
			break;
		case MEDIO_STATE:
//			if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 < MEDIO_LINEA_H) && (diff_abs2 > MEDIO_LINEA_L)) {
			if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 > MEDIO_LINEA_L)) {
				MachineState_state = MEDIO_STATE;
			}else if ((SuccCamLecturesCounter2 < 5)){// || (diff_abs2 > MEDIO_LINEA_H)) {
				MachineState_state = ALTO_STATE;
			}else if ((SuccCamLecturesCounter2 > 5) && (diff_abs2 < MEDIO_LINEA_L)) {
				MachineState_state = CENTRO_STATE;
			}
			break;
		case ALTO_STATE:
//			if ((SuccCamLecturesCounter > 5) && (diff_abs < ALTO_LINEA_H) && (diff_abs > ALTO_LINEA_L)) {
			if ((SuccCamLecturesCounter2 > 5)) {
				MachineState_state = MEDIO_STATE;
			}else if ((SuccCamLecturesCounter < 5)){// || (diff_abs > ALTO_LINEA_H)) {
				MachineState_state = EXTREMO_STATE;
//			}else if ((SuccCamLecturesCounter > 5) && (diff_abs < ALTO_LINEA_L)) {
			}else if ((SuccCamLecturesCounter > 5)) {
				MachineState_state = ALTO_STATE;
			}		
			break;
		case EXTREMO_STATE:
//			if ((SuccCamLecturesCounter > 5) && (diff_abs < EXTREMO_LINEA)) {
			if ((SuccCamLecturesCounter > 5)) {
				MachineState_state = ALTO_STATE;
			}	
			break;
		default:
			break;
	}
}

void vfnLedState(void)
{
	switch (MachineState_state) {
		case CENTRO_STATE:
			/* green on */
			red_off();
			green_on();
			blue_off();	
			break;
		case MEDIO_STATE:
			/* blue */
			red_off();
			green_off();
			blue_on();
			break;
		case ALTO_STATE:
			/* green + blue */
			red_off();
			green_on();
			blue_on();
			break;
		case EXTREMO_STATE:
			/* red on */
			red_on();
			green_off();
			blue_off();
			break;
		default:
			break;
	}
}

void vfnAlgorithmState(int8_t diff, int8_t diff2, float speed_low, float speed_high)
{
	int8_t average_steering;
	float average_speed;
	
	average_steering = (diff + diff2)/2;
	average_speed = (speed_low + speed_high)/2;
	
	switch (MachineState_state) {
		case CENTRO_STATE:
			
			vfnDiff_1(average_steering, CENTRO_STEERING_COEFF);					//Steering
			vfnSpeedDiff(average_steering, speed_high, CENTRO_SPEED_COEFF);		//Speed
			
			break;
		case MEDIO_STATE:
			
			vfnDiff_1(average_steering, MEDIO_STEERING_COEFF);				//Steering
			vfnSpeedDiff(average_steering, 0.27, MEDIO_SPEED_COEFF);		//Speed
			
			break;
		case ALTO_STATE:
			
			vfnDiff_1(diff, ALTO_STEERING_COEFF);					//Steering
			vfnSpeedDiff(diff, speed_low, ALTO_SPEED_COEFF);		//Speed
			
			break;
		case EXTREMO_STATE:
			
			vfnDiff_1(diff, EXTREMO_STEERING_COEFF);			//Steering
			vfnSpeedDiff(diff, 0.24, EXTREMO_SPEED_COEFF);		//Speed
			
			break;
		default:
			break;
	}
}
