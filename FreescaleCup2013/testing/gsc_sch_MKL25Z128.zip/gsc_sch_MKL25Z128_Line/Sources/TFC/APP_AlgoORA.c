/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            APP_AlgoORA.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Wednesday November 6 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for algorithms by Oscar									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the algorithms			  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 6/11/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"

#define CENTER_LINE		63
#define WHEEL_RIGHT		0
#define WHEEL_LEFT		1

uint8_t collision_flag = 0;
uint8_t collision_flag2 = 0;

void vfnAlgorithmsORA(void){
	float pot_0, pot_1;
	int8_t ub_center_temp;
	int8_t difference;
	uint32_t i = 0;
	
	//Read pots
	pot_0 = (MAL_ReadPot(0)+1)/2;
	pot_1 = (MAL_ReadPot(1)+1)/2;
	
	//Line position
	ub_center_temp = getLinePosition();
//	ub_center_temp = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127
	
	difference = ub_center_temp - CENTER_LINE;			//Values from -63 to 64
	
//	if(TFC_PUSH_BUTTON_0_PRESSED)
//	{	
//		vfnTwoSpeeds(difference, pot_0, pot_0);
//	}else{
//		vfnTwoSpeeds(difference, pot_1, pot_1);
//	}
	
	//Select algorithm
	switch(TFC_GetDIP_Switch()&0x03){
		case 0:
			vfnDiff_1(difference);
//			vfnDiff_Hibryd(difference);
			vfnSpeedsHard(difference, pot_0, pot_1, 0.15);	//0.12 is the theory
//			vfnSpeedsSoft(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
//			vfnTwoSpeeds(difference, pot_0, pot_1);
			
//			Tests
//			HAL_SetServo(MAL_ReadPot(0));
//			vfnConstant2(pot_0, pot_1);
//			HAL_SetMotorPWM(pot_0, pot_1);
			break;
		case 1:
//			vfnDiff_1(difference);
			vfnDiff_Hibryd(difference);
			vfnSpeedsHard(difference, pot_0, pot_1, 0.15);
//			vfnSpeedsHard(difference, pot_0, pot_1, 0.20);
//			vfnSpeedsSoft(difference, pot_0, pot_1);
//			vfnDiff_2(difference);
//			vfnTwoSpeeds(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
			break;
		case 2:
			vfnDiff_Hibryd2(difference);
			vfnSpeedsHard(difference, pot_0, pot_1, 0.15);
			
//			vfnSpeedsSoft(difference, pot_0, pot_1);
//			vfnDiff_3(difference);
//			vfnTwoSpeeds(difference, pot_0, pot_1);
//			vfnConstant(pot_0);
			break;
		case 3:
			vfnDiff_1(difference);
			vfnSpeedsHard(difference, pot_0, pot_1, 0.20);
			
//			vfnSpeedsSoft(difference, pot_0, pot_1);
//			vfnPid(difference,pot_1);
//			vfnConstant(pot_0);
			break;
	}
	
	//It sends information using serial port
	switch((TFC_GetDIP_Switch()>>2)&0x03){
		case 0:
			//Nothing
			break;
		case 1:
			//After binarization
			TERMINAL_PRINTF("%d ", pat_info.value);
			TERMINAL_PRINTF("%d ", pat_info.valid);
			TERMINAL_PRINTF("%d ", ub_Black_Strip_Center);
			TERMINAL_PRINTF("%d ", ub_Black_Strip_Width);
			TERMINAL_PRINTF("\r\n");
		 
			for(i = 0;i < 128;i++)
			{
				TERMINAL_PRINTF("%d",ub_Bin_Pixels[i]);
//				TERMINAL_PRINTF("%d",LineScanImage0[i]);
			} 
			TERMINAL_PRINTF("\r\n");
			break;
		case 2:
			//Labview application
			TERMINAL_PRINTF("\r\n");
			TERMINAL_PRINTF("L:");
				
			for(i=0;i<128;i++)
			{
				TERMINAL_PRINTF("%X,",LineScanImage0[i]);
			}
			
			for(i=0;i<128;i++)
			{
				TERMINAL_PRINTF("%X",LineScanImage1[i]);
				 
				if(i==127)
					TERMINAL_PRINTF("\r\n",LineScanImage1[i]);
				else
					TERMINAL_PRINTF(",",LineScanImage1[i]);
			}
			break;
		case 3:
			//Speed sensor
			TERMINAL_PRINTF("%d", (uint8_t)(HAL_GetSpeed(WHEEL_RIGHT)*100));
			//Steering direction
//			TERMINAL_PRINTF("%d", (uint8_t)(MAL_ReadPot(0)*1000));
			TERMINAL_PRINTF("\r\n");
			break;
	}
	
	//Turn off motors if the car doesn't detect the line
	Collision();
}
	
/*Steering*/
void vfnDiff_1(int8_t diff){
	float servo_position;
	int8_t coeff = 45;
	
	servo_position = (float)((float)diff/(float)coeff);
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_2(int8_t diff){
	float servo_position;
	int8_t coeff = 35;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position;
	
	if(diff < 0){
		servo_position = servo_position * (-1);
	}
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_3(int8_t diff){
	float servo_position;
	int8_t coeff = 40;
	
	servo_position = (float)((float)diff/(float)coeff);
	servo_position = servo_position*servo_position*servo_position;
	
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_Hibryd(int8_t diff){
	float servo_position;
	int8_t coeff_1 = 45;
	int8_t coeff_2 = 35;
	
	if((diff > -27) && (diff < 27)){	//Quadratic function
		servo_position = (float)((float)diff/(float)coeff_2);
		servo_position = servo_position*servo_position;
		
		if(diff < 0){
			servo_position = servo_position * (-1);
		}
	}else{
		servo_position = (float)((float)diff/(float)coeff_1);	//Linear
	}
		
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}

void vfnDiff_Hibryd2(int8_t diff){
	float servo_position;
	int8_t coeff_1 = 45;
	int8_t coeff_2 = 33;
	
	if((diff > -27) && (diff < 27)){	//Cube function
		servo_position = (float)((float)diff/(float)coeff_2);
		servo_position = servo_position*servo_position*servo_position;
	}else{
		servo_position = (float)((float)diff/(float)coeff_1);	//Linear
	}
		
	if(servo_position > 1.0){
		servo_position = 1.0;
	}else if(servo_position < (-1.0)){
		servo_position = -1.0;
	}
	HAL_SetServo(servo_position);
}


/*Speed*/
void vfnConstant(float speed_const){
	HAL_SetSpeed(speed_const,speed_const);				//With SPEED CONTRO
}

void vfnConstant2(float speed_right, float speed_left){
	HAL_SetSpeed(speed_right, speed_left);				//With SPEED CONTROL
}

void vfnTwoSpeeds(int8_t diff, float low_speed, float high_speed){
	float speed_wheel;
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 5;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel = high_speed;
	}else{
		speed_wheel = low_speed;
	}
	
	HAL_SetSpeed(speed_wheel,speed_wheel);				//With SPEED CONTROL
}

void vfnSpeedsHard(int8_t diff, float low_speed, float high_speed, float coeff){
	float speed_wheel_right, speed_wheel_left;
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 5;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel_right = high_speed;
		speed_wheel_left = high_speed;
	}else{
		if(diff > 0){		//Right turn
			speed_wheel_right = low_speed - (low_speed*coeff);
			speed_wheel_left =  low_speed + (low_speed*coeff);
		}else{				//Left turn
			speed_wheel_right = low_speed + (low_speed*coeff);
			speed_wheel_left =  low_speed - (low_speed*coeff);
		}
	}
	
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);				//With SPEED CONTROL
}

void vfnSpeedsSoft(int8_t diff, float low_speed, float high_speed){
	float speed_wheel_right, speed_wheel_left;
	float coeff = 1/(3*100);
	uint8_t	diff_abs;
	uint8_t diff_maxSpeed = 5;
	
	diff_abs = (uint8_t) getAbs((int16_t) diff);
	
	if(diff_abs < diff_maxSpeed){
		speed_wheel_right = high_speed;
		speed_wheel_left = high_speed;
	}else{
		if(diff > 0){		//Right turn
			speed_wheel_right = low_speed - (low_speed*(((float)diff_abs)*coeff));
			speed_wheel_left =  low_speed + (low_speed*(((float)diff_abs)*coeff));
		}else{				//Left turn
			speed_wheel_right = low_speed + (low_speed*(((float)diff_abs)*coeff));
			speed_wheel_left =  low_speed - (low_speed*(((float)diff_abs)*coeff));
		}
	}
	HAL_SetSpeed(speed_wheel_right,speed_wheel_left);				//With SPEED CONTROL
}

/* Collision */

void Collision(void)
{
	if( (FailCamLectCounter > 50) && (!collision_flag) )
	{
		SuccCamLecturesCounter = 0;
		collision_flag = 1;
		TFC_HBRIDGE_DISABLE;
	}
	
	if( (SuccCamLecturesCounter > 10) && (collision_flag) )
	{
		collision_flag = 0;
		FailCamLectCounter = 0;
		HAL_ResetPID_Values();
		TFC_HBRIDGE_ENABLE;
	}
	
//	if( (FailCamLectCounter > 5) && (!collision_flag) )
//	{
//		SuccCamLecturesCounter = 0;
//		collision_flag = 1;
//	}
//	
//	if( (SuccCamLecturesCounter > 10) && (collision_flag) )
//	{
//		collision_flag = 0;
//		FailCamLectCounter = 0;
//	}
}

int8_t getLinePosition(void)
{
	int8_t linePos = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127

//	if( SuccCamLecturesCounter > 5 )
//	{
//		/* green on */
//		red_off();
//		green_on();
//		blue_off();
//		linePos = (int8_t) ub_Black_Strip_Center; 	//Values from 0 to 127
//	}else if( (SuccCamLecturesCounter <= 10) && (SuccCamLecturesCounter2 > 5)){
//		/* green + blue */
//		red_off();
//		green_on();
//		blue_on();
//		linePos = (int8_t) ub_Black_Strip_Center2; 	//Values from 0 to 127
//	}else{
//		/* red on */
//		red_on();
//		green_off();
//		blue_off();
//		linePos = (int8_t) ub_Black_Strip_Center2; 	//Values from 0 to 127
//	}
			
	return linePos;
}
