#include "TFC\TFC.h"


void TFC_Init()
{
	//TFC_InitClock();
	InitClock();
	//TFC_InitSysTick();
	InitSysTick();
	TFC_InitGPIO();
	//TFC_InitServos();
	//TFC_InitMotorPWM();
    //TFC_InitADCs();
	InitADC0();
    //TFC_InitLineScanCamera();
    vfnInitCamera();
    vfnStartCapturing();
    TFC_InitTerminal();
//	TFC_InitUARTs();
	vfnInitStates();
	
	
	//Added
	HAL_InitMotorPWM();
//	HAL_SetMotorPWM(0.5,0.5);
	HAL_InitServos();
	init_leds();
	
	HAL_InitSpeedSensor();
//	HAL_SetSpeed(0.35);
	
	
	TFC_HBRIDGE_DISABLE;
//	TFC_HBRIDGE_ENABLE;
}

void TFC_Task()
{
	#if defined(TERMINAL_USE_SDA_SERIAL)
		TFC_UART_Process();
	#endif
	 
    TFC_ProcessTerminal();
}
