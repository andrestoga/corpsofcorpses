/*============================================================================*/
/*                   Los Aferrados Team                                       */
/*============================================================================*/
/*                        OBJECT SPECIFICATION                                */
/*============================================================================*
* name:            HAL_MOTORS.c
* version:         1.0
* %created_by:      Oscar Rodea Aragon %
* %date_created:    Tuesday October 15 13:11:01 2013 %
*=============================================================================*/
/* DESCRIPTION : Source file for DC Motors 									  */
/*============================================================================*/
/* FUNCTION COMMENT : Describes the functions for the DC motors				  */
/*              	                                                          */
/*                                                                            */
/*============================================================================*/
/*                               OBJECT HISTORY                               */
/*============================================================================*/
/*  REVISION             |   DATE      |                   |      AUTHOR      */
/*----------------------------------------------------------------------------*/
/*      1.0              | 15/10/2013 |                   | Oscar Rodea       */
/*============================================================================*/

/* Includes */
/* -------- */
#include "TFC\TFC.h"

#include "derivative.h"



/**********************************************************************************************/

#define FTM2_CLOCK				(CORE_CLOCK/2)
#define FTM2_CLK_PRESCALE       5// Prescale Selector value - see comments in Status Control (SC) section for more details
								//Divided by 32

#define COUNT_VAL				10			
#define COUNTS_MAX				18750		//Counts for a frequency of 40Hz
#define COUNTS_MIN				750			//Counts for a frequency of 1kHz

#define CHANNEL_0				0
#define CHANNEL_1				1

//HAL_SetSpeed()
float RefSpeed_right;
float RefSpeed_left;

//FTM2_IRQHandler()
uint8_t overflow_flag_0 = 0;
uint8_t overflow_flag_1 = 0;
uint16_t LastValueCh_0 = 0;
uint16_t LastValueCh_1 = 0;

//HAL_ControlSpeed()
float power_motor_right = 0;
float power_motor_left = 0;
float error_right = 0;
float error_left = 0;
float lastError_right = 0;
float lastError_left = 0;
float integral_right = 0;
float integral_left = 0;
//HAL_ProcessSpeed()
volatile uint16_t SpeedBuffer_ch0[COUNT_VAL];
volatile uint8_t index_ch0 = 0;
volatile uint16_t SpeedBuffer_ch1[COUNT_VAL];
volatile uint8_t index_ch1 = 0;


/**********************************************************************************************/
void HAL_SetSpeed(float right_speed, float left_speed){
	RefSpeed_right = right_speed;
	RefSpeed_left = left_speed;
}

float HAL_GetSpeed(uint8_t channel){			//from 0 to 1
	uint32_t average_count = 0;
	float current_speed;
	uint8_t temp = 0;
	
	if(channel == CHANNEL_0){
		//Get an average of counter
		do{
			average_count += SpeedBuffer_ch0[temp];	
			temp++;
		}while(temp<COUNT_VAL);
	}
	
	if(channel == CHANNEL_1){
		//Get an average of counter
		do{
			average_count += SpeedBuffer_ch1[temp];	
			temp++;
		}while(temp<COUNT_VAL);
	}
	
	average_count = average_count/COUNT_VAL;
	
	//Normalize speed
	if(COUNTS_MAX <= average_count){
		current_speed = 0.0;
	}else if(COUNTS_MIN > average_count){
		current_speed = 1.0;
	}else{
		current_speed = (float)((float)COUNTS_MIN/(float)average_count);
	}
	
	return current_speed;
}

void HAL_ControlSpeed(void){
//	HAL_SimpleControl();
	HAL_PID();
}

void HAL_SimpleControl(void){
//	float coeff = 0.1;	//0.5 //0.1 //0.05 //0.01		//Please see test charts in excel document
//	
//	error = RefSpeed - HAL_GetSpeed();
//	power_motor += (error*coeff);
//	
//	if(power_motor < 0){
//		power_motor = 0;
//	}else if(power_motor > 1.0){
//		power_motor = 1.0;
//	}
//	HAL_SetMotorPWM(power_motor,power_motor);
}

void HAL_PID(void){
//	float kp = 0.05;
//	float ki = 0.00001;
//	float kd = 0.9;
	float kp = 0.1;
	float ki = 0.00001;
	float kd = 0.9;
	
	float low_limit_power = -1;
	float max_limit_power = 1;
	float current_speed_right, current_speed_left;
	float derivative_right, derivative_left;
	
	current_speed_right = HAL_GetSpeed(CHANNEL_0);		//Get the current speed
	current_speed_left = HAL_GetSpeed(CHANNEL_1);		//Get the current speed
	
	error_right = RefSpeed_right - current_speed_right;	//Calculate the error
	error_left = RefSpeed_left - current_speed_left;	//Calculate the error
	
	integral_right = integral_right + error_right;		//Calculate the integral
	integral_left = integral_left + error_left;		//Calculate the integral
	
	derivative_right = error_right - lastError_right;		//Calculate the derivative
	derivative_left = error_left - lastError_left;		//Calculate the derivative
	
	power_motor_right += (kp*error_right) + (ki*integral_right) + (kd*derivative_right);			//PID controller
	power_motor_left += (kp*error_left) + (ki*integral_left) + (kd*derivative_left);			//PID controller
//	power_motor += (kp*error) + (ki*integral);			//PI controller
//	power_motor += (kp*error) + (kd*derivative);			//PD controller
//	power_motor += (kp*error);			//P controller
	
	//Limit the power_motor
	if(power_motor_right < low_limit_power){
		power_motor_right = low_limit_power;
	}else if(power_motor_right > max_limit_power){
		power_motor_right = max_limit_power;
	}
	if(power_motor_left < low_limit_power){
		power_motor_left = low_limit_power;
	}else if(power_motor_left > max_limit_power){
		power_motor_left = max_limit_power;
	}
	
	HAL_SetMotorPWM(power_motor_right, power_motor_left);
//	HAL_SetMotorPWM(power_motor_right, power_motor_right);		//For serial 
	
	//Save the current error for the next iteration
	lastError_right = error_right;
	lastError_left = error_left;
}

void HAL_ResetPID_Values(void){
	lastError_right = 0;
	lastError_left = 0;
	integral_right = 0;
	integral_left = 0;
}

void HAL_ProcessSpeed(uint16_t counts, uint8_t channel){
	if(channel == CHANNEL_0){
		SpeedBuffer_ch0[index_ch0] = counts;
		index_ch0 ++;
		if(index_ch0 >= COUNT_VAL){
			index_ch0 = 0;
		}
	}
	if(channel == CHANNEL_1){
		SpeedBuffer_ch1[index_ch1] = counts;
		index_ch1 ++;
		if(index_ch1 >= COUNT_VAL){
			index_ch1 = 0;
		}
	}
}

/******************************************* Function to control Interrupt ************************************/

void FTM2_IRQHandler()
{
	uint16_t CurrValueCh_0, CurrValueCh_1;
	
	//Clear the overflow mask if set.   According to the reference manual, we clear by writing a logic one!
	if(TPM2_SC & TPM_SC_TOF_MASK){
	   
	   overflow_flag_0 = 1;
	   overflow_flag_1 = 1;
	   LastValueCh_0 = 65535 - LastValueCh_0;
	   LastValueCh_1 = 65535 - LastValueCh_1;
	   
	   TPM2_SC |= TPM_SC_TOF_MASK;		//Clear the flag
	}
	
	//Channel 0
	if(TPM2_C0SC & TPM_CnSC_CHF_MASK){
	   //Get the current counter value
	   if(!overflow_flag_0){
		   CurrValueCh_0 = TPM2_C0V - LastValueCh_0;
	   }else{
		   CurrValueCh_0 = TPM2_C0V + LastValueCh_0;
		   overflow_flag_0 = 0;
	   }
	   LastValueCh_0 = TPM2_C0V;
	   if(CurrValueCh_0 > COUNTS_MIN){
		   HAL_ProcessSpeed(CurrValueCh_0,CHANNEL_0);
	   	}
	   TPM2_C0SC |= TPM_CnSC_CHF_MASK;	//Clear the flag
	}
	
	//Channel 1
	if(TPM2_C1SC & TPM_CnSC_CHF_MASK){
		//Get the current counter value
	   if(!overflow_flag_1){
		   CurrValueCh_1 = TPM2_C1V - LastValueCh_1;
	   }else{
		   CurrValueCh_1 = TPM2_C1V + LastValueCh_1;
		   overflow_flag_1 = 0;
	   }
	   LastValueCh_1 = TPM2_C1V;
	   if(CurrValueCh_1 > COUNTS_MIN){
		   HAL_ProcessSpeed(CurrValueCh_1,CHANNEL_1);
	   }
	   TPM2_C1SC |= TPM_CnSC_CHF_MASK;	//Clear the flag
	}
	
}

void HAL_InitSpeedSensor()
{
               
   //Clock Setup for the TPM requires a couple steps.
   
   //1st,  set the clock mux
   //See Page 124 of f the KL25 Sub-Family Reference Manual, Rev. 3, September 2012
   SIM_SOPT2 |= SIM_SOPT2_PLLFLLSEL_MASK;// We Want MCGPLLCLK/2 (See Page 196 of the KL25 Sub-Family Reference Manual, Rev. 3, September 2012)
   SIM_SOPT2 &= ~(SIM_SOPT2_TPMSRC_MASK);
   SIM_SOPT2 |= SIM_SOPT2_TPMSRC(1); //We want the MCGPLLCLK/2 (See Page 196 of the KL25 Sub-Family Reference Manual, Rev. 3, September 2012)


	//Enable the Clock to the FTM2 Module
	//See Page 207 of f the KL25 Sub-Family Reference Manual, Rev. 3, September 2012
	SIM_SCGC6 |= SIM_SCGC6_TPM2_MASK; 
   
   //The TPM Module has Clock.  Now set up the peripheral
   
   //Blow away the control registers to ensure that the counter is not running
   TPM2_SC = 0;
   TPM2_CONF = 0;
   
   //While the counter is disabled we can setup the prescaler
   
   TPM2_SC = TPM_SC_PS(FTM2_CLK_PRESCALE);
   TPM2_SC |= TPM_SC_TOIE_MASK; //Enable Interrupts for the Timer Overflow
   
   //Setup Channel 0		Rising edge only
   TPM2_C0SC =  TPM_CnSC_ELSA_MASK | TPM_CnSC_CHIE_MASK;
   TPM2_C1SC =  TPM_CnSC_ELSA_MASK | TPM_CnSC_CHIE_MASK;
   //Enable the Counter
   
   //Set the Default speed to 0
   HAL_SetSpeed(0.0,0.0);		
   
   //Enable the TPM COunter
   TPM2_SC |= TPM_SC_CMOD(1);
   
   //Enable TPM1 IRQ on the NVIC
   enable_irq (INT_TPM2-16);
  
   //Enable the FTM functions on the the port
   PORTA_PCR1 = PORT_PCR_MUX(3);
   PORTA_PCR2 = PORT_PCR_MUX(3);
}

